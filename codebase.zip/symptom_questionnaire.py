"""Adaptive clinical screening questions for GutGPT.

Questions are branch-specific and answerable in normal language. The agent
records the exact field it asked, so replies like "5 months", "23", "no", or
"yes, hard stools" are never treated as unrelated messages.
"""
import logging

from clinical_rule_engine import _duration_days
from question_schema import question_has_answer, question_has_progressed

logger = logging.getLogger("gutgpt.questionnaire")


def next_question(state):
    asked = set(state.asked_fields or [])

    def q(name, text, condition=True):
        # Show the Bristol chart immediately before any Bristol stool-type
        # question. The widget replaces this marker with its embedded chart,
        # so the image works on Shopify without a separately hosted asset.
        if name == "stool_form":
            text = (
                "[[BRISTOL_STOOL_CHART]]\n"
                "**How to identify your type:**\n"
                "1 — Hard separate pellets; difficult to pass.\n"
                "2 — Lumpy, sausage-shaped stool.\n"
                "3 — Sausage-shaped with cracks on the surface.\n"
                "4 — Smooth, soft sausage or snake shape (generally considered ideal).\n"
                "5 — Soft blobs that pass easily.\n"
                "6 — Mushy stool with ragged edges.\n"
                "7 — Entirely liquid, with no solid pieces.\n\n"
                f"{text} Please reply with a number from **1 to 7**, or say **I don't know**."
            )
        # `asked_fields` is history, not evidence that a question was answered.
        # If a prior state merge or interrupted turn left a required field empty,
        # it must remain eligible to be asked. Explicitly accepted "unknown" is
        # a valid conversational outcome and is tracked separately.
        unknown_fields = set(getattr(state, "answered_unknown_fields", []) or [])
        has_answer = question_has_progressed(state, name)
        if condition and name not in unknown_fields and (name not in asked or not has_answer):
            return name, text
        if name in {"blood_colour", "blood_location", "anal_pain", "lump", "constipation"}:
            if not condition:
                logger.info("[QUESTION][BLEEDING][SKIP] field=%s reason=not_required", name)
            elif has_answer or name in unknown_fields:
                logger.info("[QUESTION][BLEEDING][SKIP] field=%s reason=answered", name)
        return None

    # Safety-critical bleeding owns the assessment whenever bleeding has been
    # positively established, regardless of which symptom was detected first.
    # Keep all other symptoms in state; this only changes question priority.
    if state.blood_present is True:
        logger.info(
            "[QUESTION][BRANCH] bleeding_present=true selected_branch=bleeding reason=bleeding_priority"
        )
        branch = "bleeding"
    else:
        branch = state.primary_symptom

    # If the user has supplied enough information up front, these are skipped.
    # First ask duration, then conditionally ask weight-loss if duration >= 1 month,
    # then ask age.
    if state.duration == "unknown":
        return q("duration", "How long has this been happening?", True)

    # Duration is known - check if we should ask the conditional weight-loss question
    if (state.weight_loss is None
            and not state.weight_loss_duration_asked
            and state.duration != "unknown"):
        days = _duration_days(state.duration)
        if days is not None and days >= 30:
            return q("weight_loss_duration", "Have you lost any significant weight?", True)

    # Age is a demographic gate, not a symptom discriminator. Keep it before
    # the branch questions so the existing clinical assessment gates remain
    # deterministic, but never allow it to replace the branch-specific
    # questionnaire below.
    if state.age is None:
        return q("age", "What is your age?", True)

    if branch == "bleeding":
        bleeding_qs = [
            q("blood_colour", "Is the blood bright/fresh red, or dark/black/tarry?", state.blood_colour is None),
            q(
                "blood_location",
                "If it is bright red, is it on tissue, dripping into the toilet, or mixed into the stool?",
                state.blood_colour == "bright_red" and state.blood_location is None,
            ),
            q("anal_pain", "Is there sharp or tearing pain during or just after a bowel movement?", state.sharp_pain_during_stool is None),
            q("lump", "Is there a lump or something protruding from the anus?", state.lump_or_prolapse is None),
            q("constipation", "Do you have hard stools or strain when passing stool?", state.stool_form is None or state.straining is None),
        ]
        missing_fields = []
        if state.blood_colour is None:
            missing_fields.append("blood_colour")
        elif state.blood_colour == "bright_red" and state.blood_location is None:
            missing_fields.append("blood_location")
        if state.sharp_pain_during_stool is None:
            missing_fields.append("anal_pain")
        if state.lump_or_prolapse is None:
            missing_fields.append("lump")
        if state.stool_form is None or state.straining is None:
            missing_fields.append("constipation")
        answered_fields = [
            f for f, value in (
                ("blood_colour", state.blood_colour),
                ("blood_location", state.blood_location),
                ("anal_pain", state.sharp_pain_during_stool),
                ("lump", state.lump_or_prolapse),
                ("constipation", state.stool_form if state.stool_form is not None else state.straining),
            ) if value is not None
        ]
        for item in bleeding_qs:
            if item:
                logger.info(
                    "[QUESTION][BLEEDING] answered_fields=%s missing_fields=%s next=%s",
                    answered_fields, missing_fields, item[0],
                )
                return item
        logger.info("[QUESTION][BLEEDING][COMPLETE]")
        return None

    if branch in ("constipation", "hard stools"):
        # If bleeding is reported during the constipation interview, switch
        # temporarily to the bleeding differentiator before making the
        # constipation assessment. This prevents every bleed from becoming
        # an automatic piles label.
        if state.blood_present:
            bleeding_qs = [
                q("blood_colour", "Is the blood bright/fresh red, or dark/black/tarry?", state.blood_colour is None),
                q("blood_location", "If it is bright red, is it on tissue, dripping into the toilet, or mixed into the stool?", state.blood_location is None),
                q("anal_pain", "Is there sharp or tearing pain during or just after a bowel movement?", state.sharp_pain_during_stool is None),
                q("lump", "Is there a lump or something protruding from the anus?", state.lump_or_prolapse is None),
            ]
            for item in bleeding_qs:
                if item:
                    return item

        # This mirrors the requested constipation assessment while allowing
        # the engine to stop early once a useful pattern is established.
        qs = [
            q("bowel_frequency", "How many bowel movements do you usually have per week?", state.bowel_frequency_per_week is None),
            q("stool_straining", "Are your stools hard or lumpy, and do you need to strain to pass them?", state.stool_form is None or state.straining is None),
            q("incomplete_evacuation", "After passing stool, do you often feel that your bowel has not completely emptied?", state.incomplete_evacuation is None),
            q("bloating_pain", "Do you have bloating or recurring abdominal pain? If you have pain, does it improve or change after a bowel movement?", state.bloating is None or state.abdominal_pain is None),
            q("pain_relation", "If you have abdominal pain, does it improve, worsen, or change after you pass stool?", state.abdominal_pain is True and state.pain_related_to_bowel_movement is None),
            q("blood", "Have you noticed any blood in or around the stool?", state.blood_present is None),
            q("anal_pain", "Do you have severe or sharp anal pain during or just after a bowel movement?", state.sharp_pain_during_stool is None),
            q("vomiting_fever_swelling", "Any repeated vomiting, fever, or severe abdominal swelling?", state.vomiting is None or state.fever is None or state.abdominal_distension is None),
            q("water", "Roughly how much water do you drink each day?", state.water_intake is None),
            q("fibre", "Would you describe your fibre/fruit/vegetable intake as low, average, or high?", state.fibre_intake is None),
            q("medications", "Do you regularly take any medicines or supplements?", state.medications is None),
        ]
    elif branch == "diarrhea":
        qs = [
            q("daily_frequency", "How many loose or watery stools are you having per day?", state.bowel_frequency_per_day is None),
            q("stool_form", "If you know it, what Bristol Stool Scale type is it (1–7)?", not question_has_answer(state, "stool_form")),
            q("pain", "Do you have abdominal pain or cramps, and does it change after passing stool?", state.abdominal_pain is None or state.pain_related_to_bowel_movement is None),
            q("infection", "Did this begin after food poisoning, a stomach infection, travel, or antibiotics?", state.recent_infection is None),
            q("blood_mucus", "Any blood or mucus in the stool?", state.blood_present is None or state.mucus is None),
            q("night_weight_fever", "Does it wake you at night, or have you had weight loss or fever?", state.night_time_symptoms is None or state.weight_loss is None or state.fever is None),
            q("medications", "Did you start or change any medicine or supplement around the time this began?", state.medications is None),
        ]
    elif branch in ("acidity", "heartburn"):
        qs = [
            q("reflux", "Do you get a sour taste or acid/food coming back up?", getattr(state, "reflux_present", None) is None),
            q("timing", "Is it worse after meals, when lying down, or at night?", state.timing_relation is None),
            q("triggers", "Do tea/coffee, spicy, oily, or particular foods trigger it?", state.food_trigger is None and state.food_related is not False),
            q("swallowing", "Any difficulty or pain swallowing, persistent vomiting, or vomiting blood?", state.difficulty_swallowing is None or state.persistent_vomiting is None or state.vomiting_blood is None),
        ]
    elif branch in ("bloating", "gas"):
        qs = [
            q("bowel_pattern", "Do you also have constipation, diarrhea, or alternating bowel habits?", not question_has_answer(state, "bowel_pattern")),
            q("food_trigger", "Is it repeatedly linked to dairy, wheat, beans/lentils, or another particular food?", state.food_trigger is None and state.food_related is not False),
            q("pain", "Do you have recurring abdominal pain that changes with bowel movements?", state.abdominal_pain is None or state.pain_related_to_bowel_movement is None),
            q("stool_form", "What is your usual Bristol stool type, if you know it?", not question_has_answer(state, "stool_form")),
        ]
    elif branch == "stomach pain":
        qs = [
            q("pain_location", "Where exactly is the pain: upper abdomen, around the navel, lower abdomen, right side, or left side?", state.pain_location is None),
            q("severity", "How severe is it from 0–10, and is it getting worse?", state.severity == "unknown"),
            q("pain_relation", "Is it related to meals or bowel movements?", state.food_related is None or state.pain_related_to_bowel_movement is None),
            q("bowel_pattern", "Any constipation, diarrhea, mucus, or blood in the stool?", state.diarrhea is None or state.mucus is None or state.blood_present is None),
            q("vomiting_fever", "Any vomiting or fever?", state.vomiting is None or state.fever is None),
        ]
    elif branch == "indigestion":
        qs = [
            q("upper_symptoms", "Is it mainly upper-abdominal fullness, early fullness, burning, nausea, or belching?", state.abdominal_pain is None),
            q("food_relation", "Is it triggered or worsened by meals?", state.food_related is None),
            q("reflux", "Any heartburn or acid/food coming back up?", state.secondary_symptoms is None or "heartburn" not in state.secondary_symptoms),
            q("weight_swallow", "Any unexplained weight loss, difficulty swallowing, persistent vomiting, or vomiting blood?", state.weight_loss is None or state.difficulty_swallowing is None or state.persistent_vomiting is None or state.vomiting_blood is None),
        ]
    elif branch == "food intolerance":
        qs = [
            q("trigger", "Which food triggers it, and does it happen repeatedly after the same food?", state.food_trigger is None and state.food_related is not False),
            q("timing", "How soon after eating does it start?", state.timing_relation is None),
            q("symptoms", "What happens after the food: bloating, gas, diarrhea, cramps, constipation, or something else?", state.abdominal_pain is None or state.diarrhea is None),
        ]
    elif branch == "anal burning":
        qs = [
            q("blood", "Have you noticed any bleeding or blood around/after a bowel movement?", state.blood_present is None),
            q("anal_pain", "Is there sharp or tearing pain during or just after a bowel movement?", state.sharp_pain_during_stool is None),
            q("lump", "Is there a lump or something protruding from the anus?", state.lump_or_prolapse is None),
            q("constipation", "Do you have hard stools or strain when passing stool?", state.stool_form is None or state.straining is None),
        ]
    elif branch in ("piles", "anal fissures", "bleeding"):
        qs = [
            q("blood", "Have you noticed any bleeding or blood around/after a bowel movement?", state.blood_present is None),
            q("blood_colour", "Is the blood bright/fresh red, or dark/black/tarry?", state.blood_present is True and state.blood_colour is None),
            q("blood_location", "If it is bright red, is it on tissue, dripping into the toilet, or mixed into the stool?", state.blood_present is True and state.blood_colour == "bright_red" and state.blood_location is None),
            q("anal_pain", "Is there sharp or tearing pain during or just after a bowel movement?", state.sharp_pain_during_stool is None),
            q("lump", "Is there a lump or something protruding from the anus?", state.lump_or_prolapse is None),
            q("constipation", "Do you have hard stools or strain when passing stool?", state.stool_form is None or state.straining is None),
        ]
    else:
        qs = [
            q("bowel_pattern", "Do you mainly have constipation, diarrhea, or both at different times?", state.diarrhea is None),
            q("pain", "Do you have abdominal pain, and is it related to bowel movements?", state.abdominal_pain is None or state.pain_related_to_bowel_movement is None),
        ]

    for item in qs:
        if item:
            return item
    return None
