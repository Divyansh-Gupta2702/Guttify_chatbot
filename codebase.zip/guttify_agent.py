"""GutGPT multi-turn clinical screening conversation manager.

The agent has three strict layers:
1) preserve the user's original symptom branch;
2) interpret every answer against the exact question that was asked;
3) run the deterministic clinical-pattern engine before product matching.

The LLM is never responsible for deciding whether an answer is relevant or
which condition/pattern was selected.
"""
from dataclasses import dataclass, field
from threading import RLock
import re
import time
import logging
from datetime import datetime, timezone

from gibberish_checker import is_gibberish, random_gibberish_response
from greeting_checker import is_greeting, random_greeting_response
from satisfaction_checker import is_satisfied_closing, is_gratitude_only, random_closing_response
from intent_parser import (
    SymptomState, merge_state, extract_duration, extract_age,
    extract_bowel_frequency, extract_bowel_frequency_per_day,
    extract_severity, extract_lifestyle, extract_medications, extract_food_trigger, extract_food_related,
    extract_bool, extract_stool_form, normalize, extract_symptoms,
)
from symptom_questionnaire import next_question
from clinical_rule_engine import evaluate as evaluate_screening, _duration_days
from symptom_summary import build_symptom_summary, BRISTOL_LABELS
from safety_checker import (
    check_safety, detect_red_flags, derive_red_flags, is_pregnancy_or_lactation,
    pregnancy_lactation_evidence, red_flag_evidence,
)
from recommendation_engine import evaluate as evaluate_product, find_named_product, has_domain_overlap, products as ALL_PRODUCTS
from nlu_extractor import extract_natural_facts
from question_schema import QUESTION_SCHEMA, QuestionResolution, next_question_component, question_has_answer, question_has_progressed, resolve_against_active_question, validate_question_resolution
from product_concern_router import detect_product_concerns
from conversation_intelligence import (
    OPEN_SYMPTOM_REPLY, SAFE_GENERAL_FALLBACK, SCOPE_REPLY,
    answer_general_question, answer_company_question, answer_research_question, classify_intent,
)
from feature_flags import enabled

SESSION_ENDED_MESSAGE = "This conversation has already wrapped up. Please start a new chat if you'd like help with another question."
logger = logging.getLogger("gutgpt.nlu")
MAX_QUESTIONS = 15


PRODUCT_ELIGIBILITY = {
    "Functional constipation pattern": {"Digest Boost", "Guttify Poopie"},
    "Possible medication-associated constipation pattern": {"Digest Boost", "Guttify Poopie"},
    "IBS-C pattern": {"Digest Boost", "Guttify Poopie"},
    # Bowel-related abdominal pain with a documented bowel-habit change can
    # still route to Digest Boost when no safety/red-flag rule has blocked
    # product recommendations.
    "Bowel-related abdominal pain pattern": {"Digest Boost"},
    "Reflux/GERD-like symptom pattern": {"Acid Ease"},
    "Dyspepsia/indigestion pattern": {"Acid Ease"},
    # Upper-abdominal meal-related pain is not automatically an acidity case.
    # _filter_approved_products() narrows this dynamically: Digest Boost is the
    # default for stomach-pain/dyspepsia without clear acid features, while
    # Acid Ease is retained when heartburn/acidity/reflux is explicitly present.
    "Upper-abdominal meal-related dyspepsia pattern": {"Digest Boost", "Acid Ease"},
    "Food-triggered gas/bloating pattern": {"Digest Boost", "Acid Ease", "Guttify Poopie"},
    "Constipation-associated bloating pattern": {"Digest Boost", "Guttify Poopie"},
    "Functional gas/bloating pattern": {"Digest Boost", "Acid Ease", "Guttify Poopie"},
    "Possible hemorrhoid pattern": {"Piles Pure", "Piloease Anal Care Spray", "Guttify Poopie"},
    "Possible anal fissure pattern": {"Piloease Anal Care Spray"},
}

# Additional symptom-cluster routing. These are deliberately explicit rather
# than inferred from every product.json symptom field, so a broad database
# match can never silently turn into a recommendation. The completed clinical
# pattern remains the safety gate; these routes only add products for other
# symptoms that the user explicitly reported in the same assessment.
# Product bundles supplied by the business (Liver lift + Poopie mapping).
# These are product-eligibility rules, not diagnoses or claims that a product
# treats a disease. Clinical screening and red-flag checks still run first.
ADDITIONAL_SYMPTOM_PRODUCT_ELIGIBILITY = {
    "constipation": {"Digest Boost", "Guttify Poopie"},
    "hard stools": {"Digest Boost", "Guttify Poopie"},
    "acidity": {"Acid Ease", "Liver Lift"},
    "heartburn": {"Acid Ease", "Liver Lift"},
    "acid reflux": {"Acid Ease", "Liver Lift"},
    "indigestion": {"Acid Ease", "Digest Boost", "Liver Lift"},
    "digestion concerns": {"Digest Boost", "Liver Lift"},
    "bloating": {"Digest Boost", "Acid Ease", "Guttify Poopie"},
    "gas": {"Digest Boost", "Acid Ease", "Guttify Poopie"},
    "piles": {"Piles Pure", "Piloease Anal Care Spray", "Guttify Poopie"},
    "haemorrhoids": {"Piles Pure", "Piloease Anal Care Spray", "Guttify Poopie"},
    "hemorrhoids": {"Piles Pure", "Piloease Anal Care Spray", "Guttify Poopie"},
    "anal fissures": {"Piles Pure", "Piloease Anal Care Spray", "Guttify Poopie"},
}

# Product-concern branches are not medical diagnoses. They route explicit
# product-relevant concerns to the product database (skin, vitamins, weight
# management, liver support) after the gut-symptom parser has had first pick.
PRODUCT_CONCERN_QUESTIONS = {
    frozenset({"Piles Pure", "Piloease Anal Care Spray"}): (
        "Are you mainly looking for support with swelling/lumps and piles discomfort, "
        "or with burning, itching, or irritation around the anal area?"
    ),
}



def _state_reports_diarrhea(state):
    if state is None:
        return False
    if (
        getattr(state, "diarrhea", None) is True
        or getattr(state, "diarrhea_explicit", None) is True
        or str(getattr(state, "primary_symptom", "") or "").strip().lower() == "diarrhea"
    ):
        return True
    secondary = " ".join(str(item) for item in (getattr(state, "secondary_symptoms", None) or []))
    primary, symptoms = extract_symptoms(secondary)
    return primary == "diarrhea" or "diarrhea" in symptoms


def _approved_names_for_screening(screening, state=None):
    """Return the product allow-list for a completed clinical pattern.

    Upper-abdominal meal-related stomach pain is routed by the actual acid
    evidence: Digest Boost is the default; Acid Ease is used when clear
    heartburn/acidity/reflux is explicitly present.
    """
    pattern = screening.get("pattern") if isinstance(screening, dict) else None

    # None is the legacy "no condition-specific gate" sentinel below. An
    # affirmative diarrhea context must instead return an explicit empty set:
    # none of the repository's product documentation establishes eligibility
    # for acute/chronic diarrhea or IBS-D. This also prevents gas/bloating or
    # acidity matches from overriding the primary bowel condition.
    diarrhea_context = bool(
        _state_reports_diarrhea(state)
        or (isinstance(pattern, str) and "diarrhea" in pattern.lower())
        or (isinstance(screening, dict) and "ibs-d" in str(screening.get("likely_condition", "")).lower())
    )
    if diarrhea_context:
        return set()

    allowed = set(PRODUCT_ELIGIBILITY.get(pattern) or set())

    if pattern == "Upper-abdominal meal-related dyspepsia pattern" and state is not None:
        secondary = {str(x).strip().lower() for x in (state.secondary_symptoms or [])}
        clear_acid = bool(
            getattr(state, "reflux_present", None) is True
            or secondary.intersection({"acidity", "heartburn", "acid reflux"})
        )
        allowed = {"Acid Ease"} if clear_acid else {"Digest Boost"}

    # Add independently eligible products for other symptoms explicitly
    # present in this same assessment. Primary-pattern safety remains intact;
    # this only broadens the product allow-list for already reported symptom
    # clusters.
    if state is not None and allowed:
        reported = set()
        if state.primary_symptom:
            reported.add(str(state.primary_symptom).strip().lower())
        reported.update(str(x).strip().lower() for x in (state.secondary_symptoms or []))
        for symptom in reported:
            allowed.update(ADDITIONAL_SYMPTOM_PRODUCT_ELIGIBILITY.get(symptom, set()))

    return allowed or None


def _with_diarrhea_guidance(message, state=None, screening=None, session=None):
    """Add hydration guidance once per session without changing assessment rules."""
    pattern = screening.get("pattern") if isinstance(screening, dict) else ""
    has_diarrhea = bool(
        _state_reports_diarrhea(state)
        or (isinstance(pattern, str) and "diarrhea" in pattern.lower())
        or (isinstance(screening, dict) and "ibs-d" in str(screening.get("likely_condition", "")).lower())
    )
    if not has_diarrhea or (session is not None and session.diarrhea_guidance_shown):
        return message
    guidance = (
        "While we assess this, keep sipping fluids. A correctly prepared oral rehydration solution (ORS), "
        "used according to its packet instructions, can help replace fluid and salts. "
        "The available product information does not establish any Guttify product as suitable for diarrhea."
    )
    message = str(message or "").strip()
    if session is not None:
        session.diarrhea_guidance_shown = True
    return f"{guidance}\n\n{message}" if message else guidance


def _filter_approved_products(result, screening, state=None):
    """Keep product matching separate from clinical reasoning and apply a small
    explicit eligibility allow-list so generic products (for example B12) do
    not win simply because their database row contains the word constipation.
    """
    allowed = _approved_names_for_screening(screening, state)
    if allowed is None:
        return result

    if not allowed:
        result["recommendations"] = []
        result["status"] = "DIAGNOSIS"
        return result
    filtered = [p for p in result.get("recommendations", []) if p.get("product_name") in allowed]
    if filtered:
        result["recommendations"] = filtered
        # Do not destroy the recommendation engine's ambiguity decision.
        if result.get("status") != "AMBIGUOUS":
            result["status"] = "RECOMMENDATION_FOUND"
    else:
        result["recommendations"] = []
        result["status"] = "DIAGNOSIS"
    return result


@dataclass
class SessionState:
    symptom_state: SymptomState = field(default_factory=SymptomState)
    questions_asked: int = 0
    diarrhea_guidance_shown: bool = False
    last_question: str | None = None
    active_question_component: str | None = None
    awaiting_close: bool = False
    ended: bool = False
    # True after a final clinical assessment has already been delivered.
    # Once set, later messages must not restart the questionnaire/diagnosis
    # pipeline in the same session.
    diagnosis_complete: bool = False
    screening: dict | None = None
    product_candidates: list = field(default_factory=list)
    product_concern_question_asked: bool = False
    # Once a recommendation is delivered, follow-up messages must not restart
    # the clinical/product-matching pipeline. Keep the approved product here
    # so short follow-ups can stay in product-conversation mode.
    last_product: dict | None = None
    # Keep discovery results on the session so phrases like "the first one"
    # resolve without relying on process-global state. This is included in
    # the existing PostgreSQL checkpoint via dataclass serialization.
    last_products: list = field(default_factory=list)
    # Product recommendations remain blocked for the rest of this session
    # after pregnancy/lactation is disclosed.
    pregnancy_lactation_caution: bool = False
    pregnancy_lactation_provenance: dict | None = None
    safety_flag_provenance: list = field(default_factory=list)
    # True only after the user explicitly opts into a digestive assessment
    # following the pregnancy/lactation product-safety notice.
    pregnancy_assessment_started: bool = False
    # Conversation-level guard against repeating the same clarification forever.
    clarification_question: str | None = None
    clarification_response: str | None = None
    clarification_count: int = 0
    # Summary review is a confirmation gate before a non-urgent final assessment.
    awaiting_summary_confirmation: bool = False
    summary_correction_mode: bool = False
    summary_reviewed: bool = False


class ConversationManager:
    def __init__(self):
        self.sessions = {}
        self.last_access = {}
        # Protect shared maps briefly; each conversation has its own lock so a
        # slow LLM call in one session cannot block unrelated customers.
        self._lock = RLock()
        self._session_locks = {}

    def _get_session(self, sid):
        with self._lock:
            self.last_access[sid] = time.monotonic()
            return self.sessions.setdefault(sid, SessionState())

    def reset(self, sid):
        with self._lock:
            self.sessions[sid] = SessionState()
            self.last_access[sid] = time.monotonic()
            self._session_locks.setdefault(sid, RLock())

    def remove(self, sid):
        with self._lock:
            self.sessions.pop(sid, None)
            self.last_access.pop(sid, None)
            self._session_locks.pop(sid, None)

    @staticmethod
    def _set(data, key, value):
        if value is not None:
            data[key] = value

    def _apply_nlu_facts(self, session, facts):
        """Merge validated NLU facts; never diagnose or select products."""
        if not isinstance(facts, dict):
            return
        s = session.symptom_state
        data = s.to_dict()
        symptoms = [x for x in (facts.get("symptoms") or []) if isinstance(x, str)]

        primary = data.get("primary_symptom")
        if not primary and symptoms:
            data["primary_symptom"] = symptoms[0]
            primary = symptoms[0]

        secondary = list(data.get("secondary_symptoms") or [])
        for symptom in symptoms:
            if symptom != primary and symptom not in secondary:
                secondary.append(symptom)
        data["secondary_symptoms"] = secondary
        other_symptoms = list(data.get("other_symptoms") or [])
        for phrase in facts.get("other_symptoms") or []:
            if isinstance(phrase, str) and phrase.strip() and phrase.strip() not in other_symptoms:
                other_symptoms.append(phrase.strip()[:120])
        data["other_symptoms"] = other_symptoms[:8]

        def set_if(value, key):
            if value is not None:
                data[key] = value

        set_if(facts.get("duration"), "duration")
        set_if(facts.get("age"), "age")
        if facts.get("severity") in {"mild", "moderate", "severe"} or (
            isinstance(facts.get("severity"), str) and re.fullmatch(r"(?:10|[0-9])(?:\.\d+)?", facts["severity"].strip())
        ):
            data["severity"] = facts["severity"]

        for src, dst in {
            "straining": "straining",
            "weight_loss": "weight_loss",
            "lump_or_protrusion": "lump_or_prolapse",
            "itching": "itching",
            "burning": "burning",
            "swelling": "swelling",
            "gas": "gas",
            "recent_worsening": "recent_worsening",
            "vomiting": "vomiting",
            "fever": "fever",
            "bloating": "bloating",
            "diarrhea": "diarrhea",
            "constipation": "constipation_explicit",
            "reflux_present": "reflux_present",
        }.items():
            if isinstance(facts.get(src), bool):
                data[dst] = facts[src]

        if isinstance(facts.get("meal_relation"), bool):
            data["food_related"] = facts["meal_relation"]
        if facts.get("pain_relation") == "bowel_movements":
            data["pain_related_to_bowel_movement"] = True
        elif facts.get("pain_relation") == "none":
            data["pain_related_to_bowel_movement"] = False
        if isinstance(facts.get("bowel_pattern"), str):
            bp = facts["bowel_pattern"]
            if bp == "normal":
                data["constipation_explicit"] = False
                data["diarrhea"] = False
                data["diarrhea_explicit"] = False
                data["stool_form"] = None
                data["secondary_symptoms"] = [
                    x for x in (data.get("secondary_symptoms") or [])
                    if x not in {"constipation", "hard stools", "diarrhea"}
                ]
            elif bp == "constipation":
                data["constipation_explicit"] = True
                data["diarrhea"] = False
                data["diarrhea_explicit"] = False
            elif bp == "diarrhea":
                data["diarrhea"] = True
                data["diarrhea_explicit"] = True
                data["constipation_explicit"] = False
            elif bp == "mixed":
                data["constipation_explicit"] = True
                data["diarrhea"] = True
                data["diarrhea_explicit"] = True

        set_if(facts.get("pain_location"), "pain_location")

        if isinstance(facts.get("swelling"), bool) and session.last_question == "vomiting_fever_swelling":
            data["abdominal_distension"] = facts["swelling"]

        if isinstance(facts.get("hard_stools"), bool):
            data["hard_stools"] = facts["hard_stools"]
            data["stool_form"] = 2 if facts["hard_stools"] else (
                None if data.get("stool_form") in (1, 2) else data.get("stool_form")
            )
            if facts["hard_stools"] and "hard stools" not in data["secondary_symptoms"]:
                data["secondary_symptoms"].append("hard stools")

        if isinstance(facts.get("constipation"), bool):
            data["constipation_explicit"] = facts["constipation"]
            if facts["constipation"] and "constipation" not in data["secondary_symptoms"]:
                data["secondary_symptoms"].append("constipation")

        if isinstance(facts.get("loose_stools"), bool):
            data["diarrhea"] = facts["loose_stools"]
            data["diarrhea_explicit"] = facts["loose_stools"]

        if isinstance(facts.get("pain"), bool):
            body_areas = {str(x).lower() for x in (facts.get("body_areas") or [])}
            question_context = session.last_question
            anal_context = (
                question_context == "anal_pain"
                or "anal" in body_areas
                or primary in {"piles", "anal fissures", "anal burning", "anal swelling"}
            )
            abdominal_context = question_context in {"bloating_pain", "pain", "ibs_pain", "pain_relation"}
            if anal_context:
                data["anal_pain"] = facts["pain"]
            elif abdominal_context:
                data["abdominal_pain"] = facts["pain"]

        body_areas = list(data.get("body_areas") or [])
        for area in facts.get("body_areas") or []:
            if area not in body_areas:
                body_areas.append(area)
        data["body_areas"] = body_areas
        set_if(facts.get("pain_character"), "pain_character")
        set_if(facts.get("pain_timing"), "pain_timing")

        if facts.get("pain_character") in {"sharp", "sharp/tearing", "tearing", "cutting"}:
            data["sharp_pain_during_stool"] = True

        if facts.get("bleeding") is True:
            data["blood_present"] = True
            if "bleeding" not in data["secondary_symptoms"] and primary != "bleeding":
                data["secondary_symptoms"].append("bleeding")
        elif facts.get("bleeding") is False:
            data["blood_present"] = False

        if facts.get("blood_type") == "bright_red":
            data["blood_colour"] = "bright_red"
            data["blood_present"] = True
        elif facts.get("blood_type") in {"black", "dark"}:
            data["blood_colour"] = "black"
            data["blood_present"] = True

        if facts.get("blood_location") in {"tissue", "dripping", "mixed"}:
            data["blood_location"] = facts["blood_location"]

        # NLU red-flag labels are descriptive suggestions, never safety
        # evidence. The safety checker validates current text and structured
        # answers independently; model output cannot create a warning.

        # Explicit contextual negatives can correct stale generic positives.
        if facts.get("weight_loss") is False:
            data["weight_loss"] = False
        if facts.get("hard_stools") is False:
            if data.get("stool_form") in (1, 2):
                data["stool_form"] = None
            data["secondary_symptoms"] = [
                x for x in (data.get("secondary_symptoms") or [])
                if x != "hard stools"
            ]
        if facts.get("straining") is False:
            data["straining"] = False
        if facts.get("constipation") is False:
            data["constipation_explicit"] = False
            data["secondary_symptoms"] = [
                x for x in (data.get("secondary_symptoms") or [])
                if x != "constipation"
            ]

        # Explicit negatives from validated extraction correct the matching
        # symptom branch without erasing unrelated co-reported symptoms.
        negated_symptoms = {
            "gas": {"gas", "gassy"},
            "bloating": {"bloating"},
            "diarrhea": {"diarrhea", "loose stools"},
            "abdominal_pain": {"stomach pain", "abdominal pain"},
            "reflux_present": {"acidity", "heartburn"},
            "constipation": {"constipation"},
            "hard_stools": {"hard stools"},
        }
        for fact_key, labels in negated_symptoms.items():
            if facts.get(fact_key) is False:
                data["secondary_symptoms"] = [
                    item for item in (data.get("secondary_symptoms") or [])
                    if str(item).casefold() not in labels
                ]
                if str(data.get("primary_symptom") or "").casefold() in labels:
                    data["primary_symptom"] = None
        if not data.get("primary_symptom"):
            known_true = (
                ("gas", "gas"), ("bloating", "bloating"),
                ("diarrhea", "diarrhea"), ("abdominal_pain", "stomach pain"),
                ("constipation_explicit", "constipation"),
                ("reflux_present", "acidity"),
            )
            for slot, label in known_true:
                if data.get(slot) is True:
                    data["primary_symptom"] = label
                    break
        if data.get("primary_symptom"):
            data["secondary_symptoms"] = [
                x for x in (data.get("secondary_symptoms") or [])
                if str(x).casefold() != str(data["primary_symptom"]).casefold()
            ]

        session.symptom_state = SymptomState(**data)

    @staticmethod
    def _apply_volunteered_symptom_facts(session, text, facts=None):
        """Apply explicit symptom mentions independently of the active question.

        An active question owns its answer slot, but it must not discard other
        symptoms volunteered in the same turn. This small deterministic layer
        also handles explicit denials so stale state cannot survive a correction.
        """
        if not enabled("GUTGPT_MULTI_SYMPTOM_V2_ENABLED", True):
            return
        s = session.symptom_state
        raw = str(text or "")
        lower = raw.lower().replace("’", "'")
        # Split contrastive clauses so a denial of one symptom does not negate
        # a positive symptom after "but" / "however".
        clauses = re.split(r"\b(?:but|however|although)\b|[,;]|(?<=[.!?])\s+", lower)
        definitions = {
            "bloating": ("bloating", r"\b(?:bloat(?:ed|ing)?|belly feels swollen|stomach feels full of air)\b"),
            "gas": ("gas", r"\b(?:gas|gassy|flatulence|passing gas|lots of gas|excess gas)\b"),
            "diarrhea": ("diarrhea", r"\b(?:diarr(?:hea|hoea)|loose stools?|loose motions?|watery stools?)\b"),
            "abdominal_pain": ("stomach pain", r"\b(?:abdominal pain|stomach pain|belly pain|stomach ache|stomachache|cramps?)\b"),
            "blood_present": ("blood", r"\b(?:blood|bleeding|bloody stool|rectal bleeding)\b"),
        }
        positive = []
        negative = []
        for field, (label, pattern) in definitions.items():
            mentions = []
            for clause in clauses:
                if re.search(pattern, clause):
                    # The denial must be in the same clause as this symptom.
                    is_negative = bool(re.search(
                        r"\b(?:no|not|never|without|don't|dont|do not|doesn't|does not|haven't|have not|hasn't|has not)\b",
                        clause,
                    ))
                    # Common positive contrast after a negation is handled by
                    # clause splitting above (e.g. "no bloating, but gas").
                    mentions.append((is_negative, label))
            if mentions:
                # Last explicit mention wins within a clause/turn.
                is_negative, label = mentions[-1]
                (negative if is_negative else positive).append((field, label))

        data = s.to_dict()
        for field, label in negative:
            if field == "abdominal_pain":
                data["abdominal_pain"] = False
            elif field == "blood_present":
                data["blood_present"] = False
                # These questions only apply when bleeding is present. Clear
                # their old discriminators when the user corrects that fact.
                data["blood_colour"] = None
                data["blood_location"] = None
            elif field == "diarrhea":
                data["diarrhea"] = False
                data["diarrhea_explicit"] = False
            else:
                data[field] = False
            data["secondary_symptoms"] = [
                x for x in (data.get("secondary_symptoms") or [])
                if str(x).strip().lower() not in {field, label, "bloating" if field == "bloating" else label}
            ]
            if data.get("primary_symptom") in {field, label, "bloating" if field == "bloating" else label}:
                data["primary_symptom"] = None

        # Explicit positive symptoms fill canonical fields and become the
        # primary only when no still-valid primary branch exists.
        for field, label in positive:
            if field == "abdominal_pain":
                data["abdominal_pain"] = True
            elif field == "blood_present":
                data["blood_present"] = True
            elif field == "diarrhea":
                data["diarrhea"] = True
                data["diarrhea_explicit"] = True
            else:
                data[field] = True
            if not data.get("primary_symptom"):
                data["primary_symptom"] = field if field != "abdominal_pain" else "stomach pain"
            elif data.get("primary_symptom") not in {field, label}:
                secondary = list(data.get("secondary_symptoms") or [])
                if label not in secondary and field not in secondary:
                    secondary.append(label)
                data["secondary_symptoms"] = secondary

        primary = data.get("primary_symptom")
        data["secondary_symptoms"] = list(dict.fromkeys(
            x for x in (data.get("secondary_symptoms") or [])
            if x != primary and x not in {"bloating" if primary == "bloating" else None}
        ))
        # If a primary was explicitly denied, promote the first remaining
        # positive canonical symptom instead of keeping a stale branch.
        if not primary:
            for field in ("gas", "diarrhea", "bloating", "abdominal_pain"):
                if data.get(field) is True:
                    data["primary_symptom"] = "stomach pain" if field == "abdominal_pain" else field
                    break
            primary = data.get("primary_symptom")
            data["secondary_symptoms"] = [x for x in (data.get("secondary_symptoms") or []) if x != primary]
        session.symptom_state = SymptomState(**data)

    @staticmethod
    def _question_has_answer(session, field):
        """Single authoritative semantic question-completion check."""
        return question_has_answer(session.symptom_state, field)

    def _run_nlu(self, session, text, conversation_history=None):
        before = session.symptom_state.to_dict()
        current_question = session.last_question
        resolver_kwargs = ({"active_component": session.active_question_component}
                           if session.active_question_component else {})
        if conversation_history is None:
            facts = extract_natural_facts(
                text, current_question, session.symptom_state, **resolver_kwargs,
            )
        else:
            facts = extract_natural_facts(
                text, current_question, session.symptom_state, conversation_history,
                **resolver_kwargs,
            )
        # IMPORTANT: extraction is observational here. It must not mutate
        # state before active-question ownership has resolved the answer.
        after = session.symptom_state.to_dict()
        changed = {k: v for k, v in facts.items() if v not in (None, [], "", False)}

        logger.info("[NLU][QUESTION_CONTEXT] last_question=%s", current_question)
        # Do not write raw symptom/health text to application logs. Keep only
        # non-sensitive telemetry needed to diagnose extraction behavior.
        logger.debug("[NLU][RAW_REDACTED] message_length=%d", len(text or ""))
        logger.info(
            "[NLU] message_length=%d assessment_active=%s last_question=%s intent=%s confidence=%.2f",
            len(text), bool(session.symptom_state.primary_symptom or current_question),
            current_question, facts.get("intent"), facts.get("confidence", 0.0),
        )
        # Keep per-turn extraction distinct from the accumulated session
        # symptom state. Combining them under `normalized_symptoms` made an
        # answer such as "yes" appear to have re-detected an earlier symptom.
        logger.info("[NLU][EXTRACTED] fact_fields=%s current_message_symptom_count=%d session_symptom_count=%d",
                    sorted(k for k, v in facts.items() if v not in (None, [], "", False)),
                    len(facts.get("symptoms") or []),
                    int(bool(session.symptom_state.primary_symptom)) + len(session.symptom_state.secondary_symptoms or []))
        logger.info("[NLU][EXTRACTION] active_question=%s contextual_candidate_fields=%s", current_question,
                    sorted(k for k, v in facts.items() if v not in (None, [], "", False)))
        logger.info("[NLU][RESOLVER] source=%s status=%s field=%s",
                    facts.get("_resolver_source", "unknown"),
                    facts.get("_answer_status", "unresolved"),
                    current_question)
        logger.info("[NLU][MODEL_CALL] called=%s",
                    "true" if facts.get("_resolver_source") == "model" else "false")
        logger.info("[NLU][STATE_UPDATE] newly_added_field_count=%d", len(changed))
        return facts

    def _apply_answer(self, session, text, precomputed_facts=None):
        """Parse an answer using the exact question context, then merge any
        additional volunteered details without replacing the primary branch.
        """
        field = session.last_question
        s = session.symptom_state
        n = normalize(text)
        data = s.to_dict()

        # Deterministic contextual extractor is the first authority for the
        # active question. It may resolve multiple slots in one message.
        contextual = precomputed_facts if isinstance(precomputed_facts, dict) else extract_natural_facts(text, field, s)
        question_resolution = contextual.get("_question_resolution") if isinstance(contextual, dict) else None
        question_resolution = validate_question_resolution(question_resolution)
        resolution_is_unresolved = question_resolution.get("status") in {"unresolved", "clarification_needed"}
        resolution_is_partial = question_resolution.get("status") == "partial"
        resolved_active_values = question_resolution.get("values") or {}
        active_owned = set((QUESTION_SCHEMA.get(field).fields if QUESTION_SCHEMA.get(field) else set()))
        protected_active_values = {k: data.get(k) for k in active_owned}
        invalid_unresolved_fields = []
        if isinstance(contextual.get("_question_resolution") if isinstance(contextual, dict) else None, dict):
            raw_resolution = contextual["_question_resolution"]
            if raw_resolution.get("status") in {"unresolved", "clarification_needed"} and raw_resolution.get("values"):
                invalid_unresolved_fields = list(raw_resolution.get("values", {}).keys())
        if invalid_unresolved_fields:
            logger.warning("[NLU][RESOLUTION_GUARD] INVALID unresolved_with_values fields=%s", invalid_unresolved_fields)
        # Unknown is a resolved conversational outcome, not a clinical value.
        # Record the question as completed without writing True/False/None into
        # the clinical slot, so diagnosis and safety rules never treat "I don't
        # know" as evidence either way.
        if isinstance(question_resolution, dict) and question_resolution.get("status") in {"unknown", "refused"}:
            resolution_status = question_resolution["status"]
            target_name = "refused_fields" if resolution_status == "refused" else "answered_unknown_fields"
            answer_fields = list(question_resolution.get("refused_fields") or []) if resolution_status == "refused" else [field]
            recorded_fields = list(getattr(s, target_name, []) or [])
            for answer_field in answer_fields:
                if answer_field and answer_field not in recorded_fields:
                    recorded_fields.append(answer_field)
            setattr(s, target_name, recorded_fields)
            if field == "stool_form":
                s.stool_form = "unknown"
            s.red_flags = derive_red_flags(s)
            logger.info("[NLU][ANSWER] field=%s value=%s status=%s", field, resolution_status, resolution_status)
            logger.info("[NLU][CONFIDENCE] type=deterministic value=%.2f", float(question_resolution.get("confidence") or 0.99))
            logger.info("[QUESTION][RESOLUTION] field=%s value=%s status=%s confidence=%.2f", field, resolution_status, resolution_status, float(question_resolution.get("confidence") or 0.99))
            return QuestionResolution(
                field=field,
                answered=True,
                values={k: getattr(s, k, None) for k in (QUESTION_SCHEMA.get(field).fields if QUESTION_SCHEMA.get(field) else set())},
                confidence=float(question_resolution.get("confidence") or 0.99),
                clarification_needed=False,
                answer_status=resolution_status,
                source="deterministic",
            )

        partial_unknowns = question_resolution.get("unknown_fields") or []
        partial_refusals = question_resolution.get("refused_fields") or []
        for target_name, answer_fields in (
            ("answered_unknown_fields", partial_unknowns),
            ("refused_fields", partial_refusals),
        ):
            recorded_fields = list(data.get(target_name) or [])
            for answer_field in answer_fields:
                if answer_field and answer_field not in recorded_fields:
                    recorded_fields.append(answer_field)
            data[target_name] = recorded_fields

        if field == "vomiting_fever_swelling" and isinstance(contextual.get("swelling"), bool):
            data["abdominal_distension"] = contextual["swelling"]

        # Question-aware NLU facts that map 1:1 to state slots are applied
        # before legacy compatibility handlers. These are contextual facts,
        # not generic extraction.
        for _key in (
            "vomiting", "fever", "weight_loss", "hard_stools", "straining",
            "incomplete_evacuation", "recent_worsening", "reflux_present",
            "difficulty_swallowing", "persistent_vomiting", "vomiting_blood",
            "lump_or_protrusion", "meal_relation", "gas", "itching", "burning",
            "swelling", "constipation", "loose_stools", "bloating",
        ):
            if isinstance(contextual.get(_key), bool):
                if _key == "lump_or_protrusion":
                    data["lump_or_prolapse"] = contextual[_key]
                elif _key == "constipation":
                    data["constipation_explicit"] = contextual[_key]
                elif _key == "loose_stools":
                    data["diarrhea"] = contextual[_key]
                    data["diarrhea_explicit"] = contextual[_key]
                elif _key == "meal_relation":
                    data["food_related"] = contextual[_key]
                else:
                    data[_key] = contextual[_key]
                    if _key == "hard_stools" and contextual[_key] is False:
                        data["stool_form"] = None
                        data["secondary_symptoms"] = [
                            x for x in (data.get("secondary_symptoms") or [])
                            if x != "hard stools"
                        ]


        # The contextual NLU is authoritative for the active question. The
        # legacy field-specific parsers below remain as compatibility fallbacks,
        # but they must not overwrite a correctly understood natural-language
        # answer with None. This closes gaps such as "absolutely", "yes
        # sometimes", "it does", and long-form numeric/lifestyle answers.
        contextual_to_state = {
            "incomplete_evacuation": "incomplete_evacuation",
            "blood": "bleeding",
            "anal_pain": "pain",
            "lump": "lump_or_prolapse",
            "weight_loss": "weight_loss",
            "weight_loss_duration": "weight_loss",
            "infection": "recent_infection",
            "pain": "pain",
            "timing": "timing_relation",
        }
        key = contextual_to_state.get(field)
        if key and isinstance(contextual.get(key), bool):
            if key == "bleeding":
                data["blood_present"] = contextual[key]
            elif key == "pain":
                if field == "anal_pain":
                    data["anal_pain"] = contextual[key]
                    data["sharp_pain_during_stool"] = contextual[key]
                elif field in {"bloating_pain", "pain", "pain_relation"}:
                    data["abdominal_pain"] = contextual[key]
            elif key == "lump_or_prolapse":
                data["lump_or_prolapse"] = contextual[key]
            else:
                data[key] = contextual[key]

        if field == "timing":
            for k in ("meal_timing", "symptom_onset_after_food", "timing_relation"):
                if contextual.get(k) is not None:
                    data[k] = contextual[k]
            # Preserve legacy night flag for downstream rules, while timing_relation
            # remains the authoritative completion slot.
            if contextual.get("timing_relation") == "at_night":
                data["night_time_symptoms"] = True
            elif contextual.get("timing_relation") == "not_meal_related":
                data["night_time_symptoms"] = False

        if isinstance(contextual.get("incomplete_evacuation"), bool):
            data["incomplete_evacuation"] = contextual["incomplete_evacuation"]
        if isinstance(contextual.get("pain_related_to_bowel_movement"), bool):
            data["pain_related_to_bowel_movement"] = contextual["pain_related_to_bowel_movement"]
        if isinstance(contextual.get("water_intake"), str):
            m_water = re.search(r"(\d+(?:\.\d+)?)", contextual["water_intake"])
            data["water_intake"] = (m_water.group(1) + " L") if m_water else contextual["water_intake"]
        if isinstance(contextual.get("fibre_intake"), str):
            data["fibre_intake"] = contextual["fibre_intake"]
        if isinstance(contextual.get("medications"), str):
            data["medications"] = contextual["medications"]
        if field == "age" and contextual.get("age") is not None:
            data["age"] = contextual["age"]
        if field == "duration" and contextual.get("duration"):
            data["duration"] = contextual["duration"]

        if field == "severity" and contextual.get("severity") is not None:
            data["severity"] = contextual["severity"]
            if isinstance(contextual.get("recent_worsening"), bool):
                data["recent_worsening"] = contextual["recent_worsening"]

        # Apply volunteered symptoms from NLU extraction (multi-fact messages)
        symptoms = [x for x in (contextual.get("symptoms") or []) if isinstance(x, str)]
        primary = data.get("primary_symptom")
        if not primary and symptoms:
            data["primary_symptom"] = symptoms[0]
            primary = symptoms[0]
        secondary = list(data.get("secondary_symptoms") or [])
        for symptom in symptoms:
            if symptom != primary and symptom not in secondary:
                secondary.append(symptom)
        data["secondary_symptoms"] = secondary

        if field == "bowel_pattern" and contextual.get("bowel_pattern"):
            bp = contextual["bowel_pattern"]
            if bp == "normal":
                data["constipation_explicit"] = False
                data["diarrhea"] = False
                data["diarrhea_explicit"] = False
                data["stool_form"] = None
                data["secondary_symptoms"] = [
                    x for x in (data.get("secondary_symptoms") or [])
                    if x not in {"constipation", "hard stools", "diarrhea"}
                ]
            elif bp == "constipation":
                data["constipation_explicit"] = True
                data["diarrhea"] = False
                data["diarrhea_explicit"] = False
            elif bp == "diarrhea":
                data["diarrhea"] = True
                data["diarrhea_explicit"] = True
                data["constipation_explicit"] = False
            elif bp == "mixed":
                data["constipation_explicit"] = True
                data["diarrhea"] = True
                data["diarrhea_explicit"] = True
        if field == "pain_location" and contextual.get("pain_location"):
            data["pain_location"] = contextual["pain_location"]
        if field in {"pain_relation", "food_relation"}:
            if contextual.get("meal_relation") is True:
                data["food_related"] = True
            if contextual.get("pain_relation") == "bowel_movements":
                data["pain_related_to_bowel_movement"] = True
            elif contextual.get("pain_relation") == "none":
                data["food_related"] = False
                data["pain_related_to_bowel_movement"] = False

        if field == "duration":
            if contextual.get("duration"):
                data["duration"] = contextual["duration"]
            else:
                self._set(data, "duration", extract_duration(text))

        elif field == "age":
            if contextual.get("age") is not None:
                data["age"] = contextual["age"]
            else:
                self._set(data, "age", extract_age(text))

        elif field == "bowel_frequency":
            value = extract_bowel_frequency(text)
            if value is None and normalize(text).replace(".", "", 1).isdigit():
                value = float(normalize(text))
            self._set(data, "bowel_frequency_per_week", value)

        elif field == "daily_frequency":
            self._set(data, "bowel_frequency_per_day", extract_bowel_frequency_per_day(text))

        elif field in ("stool_straining", "constipation"):
            # Both question IDs exist in older questionnaire branches. Treat
            # them as the same semantic slot so a branch cannot ask the same
            # stool/strain question forever.
            stool_form = extract_stool_form(text)
            self._set(data, "stool_form", stool_form)
            # A bare yes/no answers the combined constipation question as a
            # whole; it must not be reused as a yes/no answer for one arbitrary
            # sub-feature such as straining.
            if n in {"yes", "yeah", "yep", "yup", "sure", "true"}:
                v = None
            elif n in {"no", "nope", "nah", "none", "false"}:
                v = False
            else:
                v = extract_bool(
                    text,
                    ["strain", "straining", "push hard", "pushing hard"],
                    ["no strain", "no straining", "without straining", "don't strain", "dont strain", "do not strain", "not strain", "never strain", "don't have to strain", "dont have to strain", "do not have to strain"],
                )
            self._set(data, "straining", v)
            # A natural-language combined negative answers both requested
            # dimensions, even when it does not literally say "constipation".
            if data.get("hard_stools") is False and data.get("straining") is False:
                data["constipation_explicit"] = False

            # Explicit constipation answers are useful even when the user does
            # not specify which supporting feature they mean.
            if n in {"no", "nope", "nah", "none", "false"} or re.search(r"\b(?:no|not|never|without|dont|don't|do not)\s+(?:have\s+)?(?:constipation|constipated)\b", n):
                data["constipation_explicit"] = False
                if stool_form is None:
                    data["stool_form"] = None
                data["straining"] = False if v is None else v
            elif n in {"yes", "yeah", "yep", "yup", "sure", "true"} or re.search(r"\b(?:constipation|constipated)\b", n):
                data["constipation_explicit"] = True

        elif field == "incomplete_evacuation":
            v = extract_bool(text,
                             ["incomplete evacuation", "not completely empty", "not fully empty", "still feel like i need to go", "feel incompletely empty", "yes", "yeah", "yep"],
                             ["complete evacuation", "completely empty", "fully empty", "no"])
            self._set(data, "incomplete_evacuation", v)

        elif field in ("bloating_pain", "pain"):
            if n not in {"yes", "yeah", "yep", "yup", "sure", "true"}:
                self._set(data, "bloating", extract_bool(text, ["bloating", "bloated", "bloat"], ["no bloating", "not bloated"]))
                self._set(data, "abdominal_pain", extract_bool(text, ["abdominal pain", "stomach pain", "belly pain", "stomach ache", "cramps", "cramping"], ["no abdominal pain", "no stomach pain", "no pain", "no"]))
                self._set(data, "pain_related_to_bowel_movement", extract_bool(text,
                    ["pain improves after stool", "pain improves after bowel movement", "pain relieved after stool", "pain relieved after bowel movement", "better after bowel movement", "worse after bowel movement", "related to bowel movement", "changes with bowel movement"],
                    ["not related to bowel movement", "not related to stool", "no pain"]))

        elif field in ("pain_relation", "ibs_pain"):
            self._set(data, "pain_related_to_bowel_movement", extract_bool(text,
                ["improves after bowel movement", "improves after stool", "better after bowel movement", "better after stool", "relieved after bowel movement", "worse after bowel movement", "related to bowel movement", "changes with bowel movement"],
                ["not related to bowel movement", "not related to bowel movements", "not related to stool", "no bowel relation"]))
            # The stomach-pain question asks about meals OR bowel movements.
            # Capture an explicit meal answer as a valid part of that slot.
            meal_relation = extract_bool(
                text,
                ["after meals", "after meal", "after eating", "after food", "when i eat", "whenever i eat", "related to meals", "triggered by meals"],
                ["not after meals", "not after meal", "not after eating", "not related to meals", "not triggered by meals", "not related to food"]
            )
            self._set(data, "food_related", meal_relation)

        elif field == "blood":
            v = extract_bool(text, ["blood", "bleeding", "yes", "yeah", "yep"], ["no blood", "no bleeding", "without blood", "no"])
            self._set(data, "blood_present", v)

        elif field == "blood_colour":
            if any(x in n for x in ["black", "tarry", "dark"]):
                data["blood_colour"] = "black"
            elif any(x in n for x in ["bright red", "fresh red", "fresh blood", "red"]):
                data["blood_colour"] = "bright_red"

        elif field == "blood_location":
            if any(x in n for x in ["tissue", "toilet paper"]): data["blood_location"] = "tissue"
            elif "dripping" in n: data["blood_location"] = "dripping"
            elif "mixed" in n: data["blood_location"] = "mixed"

        elif field == "anal_pain":
            v = extract_bool(text, ["sharp", "tearing", "anal pain", "pain during stool", "yes", "yeah", "yep"], ["no sharp pain", "no tearing pain", "no anal pain", "no pain", "no"])
            self._set(data, "sharp_pain_during_stool", v)
            self._set(data, "anal_pain", v)

        elif field == "lump":
            v = extract_bool(text, ["lump", "prolapse", "comes out", "yes", "yeah", "yep"], ["no lump", "no prolapse", "no"])
            self._set(data, "lump_or_prolapse", v)

        elif field == "weight_loss":
            self._set(data, "weight_loss", extract_bool(text, ["weight loss", "losing weight", "lost weight", "have lost weight", "i lost weight", "yes", "yeah", "yep"], ["no weight loss", "not losing weight", "no"]))

        elif field == "weight_loss_duration":
            # Conditional weight-loss question triggered by duration >= 1 month
            self._set(data, "weight_loss", extract_bool(text, ["weight loss", "losing weight", "lost weight", "have lost weight", "i lost weight", "yes", "yeah", "yep"], ["no weight loss", "not losing weight", "no"]))
            data["weight_loss_duration_asked"] = True

        elif field == "vomiting_fever_swelling":
            if n not in {"yes", "yeah", "yep", "yup", "sure", "true"}:
                if contextual.get("vomiting") is None:
                    self._set(data, "vomiting", extract_bool(text, ["vomiting", "vomit", "throwing up"], ["no vomiting", "not vomiting", "no"]))
                if contextual.get("fever") is None:
                    self._set(data, "fever", extract_bool(text, ["fever", "high temperature"], ["no fever", "no"]))
                if contextual.get("swelling") is None:
                    self._set(data, "abdominal_distension", extract_bool(text, ["severe swelling", "severe abdominal swelling", "severe abdominal distension", "very swollen"], ["no severe swelling", "no swelling", "no"]))

        elif field == "vomiting_fever":
            if n not in {"yes", "yeah", "yep", "yup", "sure", "true"}:
                if contextual.get("vomiting") is None:
                    self._set(data, "vomiting", extract_bool(text, ["vomiting", "vomit", "throwing up"], ["no vomiting", "not vomiting", "no"]))
                if contextual.get("fever") is None:
                    self._set(data, "fever", extract_bool(text, ["fever", "high temperature"], ["no fever", "no"]))

        elif field == "blood_mucus":
            if n in {"yes", "yeah", "yep", "yup", "sure", "true"}:
                pass
            else:
                self._set(data, "blood_present", extract_bool(text, ["blood", "bleeding"], ["no blood", "no bleeding", "no"]))
                self._set(data, "mucus", extract_bool(text, ["mucus"], ["no mucus", "no"]))

        elif field == "red_flag_check":
            flags = detect_red_flags(text)
            if flags:
                data["red_flags"] = list(dict.fromkeys((s.red_flags or []) + flags))

        elif field == "water":
            water, _ = extract_lifestyle(text)
            if water:
                m_water = re.search(r"(\d+(?:\.\d+)?)", water)
                data["water_intake"] = (m_water.group(1) + " L") if m_water else water
            else:
                m = re.search(r"\b(\d+(?:\.\d+)?)\s*(?:litres?|liters?|litters?|l)\b", n)
                if m:
                    data["water_intake"] = m.group(1) + " L"
                elif re.fullmatch(r"(?:one|two|three|four|five|six)\s*(?:litres?|liters?|litters?|l)?", n):
                    words = {"one":"1", "two":"2", "three":"3", "four":"4", "five":"5", "six":"6"}
                    data["water_intake"] = words[n.split()[0]] + " L"
                elif re_fullmatch_number(text):
                    data["water_intake"] = normalize(text) + " L"

        elif field == "fibre":
            _, fibre = extract_lifestyle(text)
            if fibre:
                data["fibre_intake"] = fibre
            elif n in {"low", "low fibre", "low fiber"}: data["fibre_intake"] = "low"
            elif n in {"average", "normal", "average fibre", "average fiber"}: data["fibre_intake"] = "average"
            elif n in {"high", "high fibre", "high fiber", "good"}: data["fibre_intake"] = "high"

        elif field in ("medications",):
            self._set(data, "medications", extract_medications(text) or ("none" if n in {"no", "none", "no medicines", "no medication", "no medications", "no supplements", "not taking anything"} else None))

        elif field == "infection":
            self._set(data, "recent_infection", extract_bool(text,
                ["food poisoning", "stomach infection", "gut infection", "gastroenteritis", "after an infection", "yes", "yeah", "yep"],
                ["no recent infection", "no infection", "no"]))

        elif field in ("night_weight_fever",):
            if n not in {"yes", "yeah", "yep", "yup", "sure", "true"}:
                self._set(data, "night_time_symptoms", extract_bool(text, ["wakes me at night", "wake me at night", "at night"], ["not at night", "doesn't wake me", "does not wake me", "no"]))
                self._set(data, "weight_loss", extract_bool(text, ["weight loss", "losing weight"], ["no weight loss", "not losing weight", "no"]))
                self._set(data, "fever", extract_bool(text, ["fever"], ["no fever", "no"]))

        elif field in ("swallowing", "weight_swallow"):
            if n not in {"yes", "yeah", "yep", "yup", "sure", "true"}:
                self._set(data, "difficulty_swallowing", extract_bool(
                    text,
                    ["difficulty swallowing", "trouble swallowing", "painful swallowing"],
                    ["no difficulty swallowing", "no trouble swallowing", "no painful swallowing", "no"]
                ))
                self._set(data, "persistent_vomiting", extract_bool(
                    text,
                    ["persistent vomiting", "vomiting repeatedly", "can't stop vomiting", "cant stop vomiting"],
                    ["no vomiting", "not vomiting", "no"]
                ))
                self._set(data, "vomiting_blood", extract_bool(
                    text,
                    ["vomiting blood", "throwing up blood", "hematemesis"],
                    ["no vomiting blood", "not vomiting blood", "no"]
                ))

        elif field == "upper_symptoms":
            # The indigestion questionnaire asks about upper-GI discomfort in
            # several natural forms (fullness, early satiety, burning, nausea,
            # belching). Store the presence of upper abdominal discomfort so
            # the questionnaire can advance without inventing a new clinical
            # state field. Meal association is collected separately.
            v = extract_bool(
                text,
                [
                    "upper abdominal fullness", "upper fullness", "fullness",
                    "early fullness", "early satiety", "burning", "nausea",
                    "nauseous", "belching", "burping", "upper abdominal discomfort",
                ],
                ["none", "no symptoms"]
            )
            self._set(data, "abdominal_pain", v)

        elif field == "symptoms":
            # Capture the main symptom categories named in the food-intolerance
            # question so its branch-specific screening can actually advance.
            n2 = normalize(text)
            if any(term in n2 for term in ("diarrhea", "diarrhoea", "loose stool", "loose stools", "loose motion")):
                data["diarrhea"] = True
            if any(term in n2 for term in ("constipation", "constipated", "hard stool", "hard stools")):
                data["secondary_symptoms"] = list(dict.fromkeys((data.get("secondary_symptoms") or []) + ["constipation"]))
            if any(term in n2 for term in ("abdominal pain", "stomach pain", "belly pain", "cramps", "cramping")):
                data["abdominal_pain"] = True
            if any(term in n2 for term in ("bloating", "bloated", "gas")):
                data["bloating"] = True

        elif field == "reflux":
            # `reflux_present` is a questionnaire slot only; it is deliberately
            # separate from `food_related`, which means meal association.
            if contextual.get("reflux_present") is not None:
                data["reflux_present"] = contextual["reflux_present"]
            else:
                data["reflux_present"] = extract_bool(
                    text,
                    ["acid coming back up", "acid reflux", "sour taste", "food coming back up", "regurgitation", "yes"],
                    ["no acid coming up", "no reflux", "no sour taste", "no food coming back up", "no"]
                )

        elif field == "timing":
            for k in ("meal_timing", "symptom_onset_after_food", "timing_relation"):
                if contextual.get(k) is not None:
                    data[k] = contextual[k]
            if contextual.get("timing_relation") == "at_night":
                data["night_time_symptoms"] = True
            elif contextual.get("timing_relation") == "not_meal_related":
                data["night_time_symptoms"] = False

        elif field == "food_relation":
            data["food_related"] = extract_bool(
                text,
                ["after meals", "after meal", "after eating", "after food", "when i eat", "whenever i eat", "related to meals", "triggered by meals"],
                ["not after meals", "not after meal", "not after eating", "not related to meals", "not triggered by meals", "not related to food", "no"]
            )
            if data.get("food_related") is None:
                self._set(data, "food_related", extract_food_related(text))

        elif field in ("triggers", "food_trigger", "trigger"):
            trigger = extract_food_trigger(text)
            if trigger:
                data["food_trigger"] = trigger
                data["food_related"] = True
            elif re.search(r"\b(no|none|not|never|no particular|nothing)\b", n):
                # Explicitly answered: no repeatable food trigger. Keep the
                # canonical trigger field empty and record the negative in the
                # meal-association slot so the questionnaire can advance.
                data["food_related"] = False

        elif field == "stool_form":
            if (
                re.fullmatch(r"(?:i\s+)?(?:dont|don't|do not|don t)\s+know", n)
                or re.fullmatch(r"(?:not sure|unsure|no idea|i have no idea)", n)
                or re.fullmatch(r"i(?:\s+am| m)?\s+not\s+sure", n)
                or re.fullmatch(r"(?:i\s+)?(?:cant|can t)\s+tell", n)
            ):
                data["stool_form"] = "unknown"
            else:
                self._set(data, "stool_form", extract_stool_form(text))

        elif field == "severity":
            value = extract_severity(text)
            if value is None and re_fullmatch_number(text):
                try:
                    score = float(normalize(text))
                    if 0 <= score <= 10:
                        value = str(int(score)) if score.is_integer() else str(score)
                except ValueError:
                    pass
            self._set(data, "severity", value)

        elif field == "pain_location":
            if "upper" in n: data["pain_location"] = "upper abdomen"
            elif "lower" in n: data["pain_location"] = "lower abdomen"
            elif "right" in n: data["pain_location"] = "right side"
            elif "left" in n: data["pain_location"] = "left side"
            elif "navel" in n or "belly button" in n: data["pain_location"] = "around navel"

        elif field == "bowel_pattern":
            primary, secondary = extract_symptoms(text)
            symptoms = []
            if primary:
                symptoms.append(primary)
            symptoms.extend(secondary or [])
            for symptom in symptoms:
                if symptom == "constipation":
                    data["secondary_symptoms"] = list(dict.fromkeys((data.get("secondary_symptoms") or []) + ["constipation"]))
                elif symptom == "hard stools":
                    data["stool_form"] = data.get("stool_form") or 1
                    data["secondary_symptoms"] = list(dict.fromkeys((data.get("secondary_symptoms") or []) + ["hard stools"]))
                elif symptom == "diarrhea":
                    data["diarrhea"] = True
                    data["secondary_symptoms"] = list(dict.fromkeys((data.get("secondary_symptoms") or []) + ["diarrhea"]))
            # Explicit negatives should clear any stale positive collected
            # from an earlier answer.
            if re.search(r"\b(?:no|not|never|without|don\'t|dont|doesn\'t|doesnt)\s+(?:have\s+)?(?:constipation|constipated|hard stool|hard stools)\b", n):
                data["secondary_symptoms"] = [x for x in (data.get("secondary_symptoms") or []) if x not in {"constipation", "hard stools"}]
                if data.get("stool_form") in (1, 2):
                    data["stool_form"] = None
            if re.search(r"\b(?:no|not|never|without|don\'t|dont|doesn\'t|doesnt)\s+(?:have\s+)?(?:diarrhea|diarrhoea|loose stool|loose stools|loose motion)\b", n):
                data["diarrhea"] = False
                data["secondary_symptoms"] = [x for x in (data.get("secondary_symptoms") or []) if x != "diarrhea"]

        # The validated resolver owns the active question. Re-apply only the
        # values it actually detected after legacy compatibility handlers so a
        # generic parser cannot overwrite a contextual negative/positive.
        if question_resolution.get("status") in {"answered", "partial"}:
            for _key, _value in (question_resolution.get("values") or {}).items():
                if _key == "lump_or_prolapse":
                    data["lump_or_prolapse"] = _value
                elif _key == "constipation_explicit":
                    data["constipation_explicit"] = _value
                elif _key == "diarrhea_explicit":
                    data["diarrhea_explicit"] = _value
                    data["diarrhea"] = _value
                elif _key == "blood_present":
                    data["blood_present"] = _value
                elif _key == "pain_related_to_bowel_movement":
                    data["pain_related_to_bowel_movement"] = _value
                elif _key in data:
                    data[_key] = _value

        # Generic extraction is subordinate to the active question. It may add
        # clearly explicit volunteered facts, but contextual/implicit facts that
        # belong to another field are discarded.
        merged = merge_state(SymptomState(**data), text, [])
        merged_data = merged.to_dict()

        # Re-assert resolver-owned values after generic merge_state as well;
        # legacy phrase matching must not overturn a validated contextual fact.
        if question_resolution.get("status") == "answered":
            for _key, _value in (question_resolution.get("values") or {}).items():
                if _key == "lump_or_prolapse":
                    merged_data["lump_or_prolapse"] = _value
                elif _key == "constipation_explicit":
                    merged_data["constipation_explicit"] = _value
                elif _key == "diarrhea_explicit":
                    merged_data["diarrhea_explicit"] = _value
                    merged_data["diarrhea"] = _value
                elif _key == "blood_present":
                    merged_data["blood_present"] = _value
                elif _key == "pain_related_to_bowel_movement":
                    merged_data["pain_related_to_bowel_movement"] = _value
                elif _key in merged_data:
                    merged_data[_key] = _value

        # Unresolved/ambiguous turns may still contribute explicitly volunteered
        # unrelated facts, but they can never change facts owned by the active
        # question. This preserves the existing discarded-unrelated-facts
        # behavior without allowing fallback defaults to answer the question.
        if resolution_is_unresolved:
            for _k, _v in protected_active_values.items():
                merged_data[_k] = _v
            logger.info("[NLU][RESOLUTION_GUARD] status=%s facts_written=0", question_resolution.get("status"))

        active_owned = set((QUESTION_SCHEMA.get(field).fields if QUESTION_SCHEMA.get(field) else set()))
        normalized = n

        def explicit_field(f):
            if f in {"answered_unknown_fields", "refused_fields"}:
                return True
            patterns = {
                "duration": r"\b(?:for|since|started|began|been having|lasting|lasted|ago)\b.{0,80}\b(?:\d+(?:\.\d+)?|one|two|three|four|five|six|seven|eight|nine|ten)\s*(?:hours?|days?|weeks?|months?|years?)\b",
                "age": r"\b(?:i am|i'm|im|my age is|aged)\s*\d{1,3}\b",
                "severity": r"\b(?:pain|severity)\s*(?:is|of|around|about)?\s*(?:10|[0-9])(?:\s*/\s*10)?\b",
                "weight_loss": r"\b(?:lost|losing|loss of|gained|put on)\s+(?:a little\s+|significant\s+|any\s+)?weight\b",
                "blood_present": r"\b(?:blood|bleeding|blood in stool|rectal bleeding)\b",
                "blood_colour": r"\b(?:bright red|fresh red|dark|black|tarry)\b",
                "blood_location": r"\b(?:toilet paper|tissue|dripping|mixed into the stool)\b",
                "reflux_present": r"\b(?:acid reflux|acid coming back up|sour taste|food coming back up|regurgitation)\b",
                "vomiting": r"\b(?:vomit(?:ing)?|throwing up)\b",
                "fever": r"\bfever\b",
                "abdominal_distension": r"\b(?:severe swelling|abdominal swelling|abdominal distension|very swollen)\b",
                "difficulty_swallowing": r"\b(?:difficulty|trouble|painful) swallowing\b",
                "persistent_vomiting": r"\b(?:persistent vomiting|vomiting repeatedly|can't stop vomiting|cant stop vomiting)\b",
                "vomiting_blood": r"\b(?:vomiting blood|throwing up blood|hematemesis)\b",
                "water_intake": r"\b\d+(?:\.\d+)?\s*(?:litres?|liters?|l)\b",
                "fibre_intake": r"\b(?:low|average|normal|high|good|poor)\s+(?:fibre|fiber)\b",
                "medications": r"\b(?:medicine|medication|medicines|supplement|supplements|taking)\b",
                "recent_infection": r"\b(?:infection|food poisoning|gastroenteritis|antibiotics|travel)\b",
                "recent_worsening": r"\b(?:getting worse|worsening|worsened|not getting worse|stable|unchanged|no change)\b",
                "food_related": r"\b(?:after meals?|after eating|after food|related to meals?|not related to meals?)\b",
                "food_trigger": r"\b(?:trigger|triggers|dairy|wheat|beans?|lentils?|spicy|oily|coffee|tea)\b",
                "pain_related_to_bowel_movement": r"\b(?:after bowel movement|after stool|related to bowel movement|changes? with bowel movement|not related to bowel movement)\b",
                "pain_location": r"\b(?:upper|lower|right|left|navel|belly button)\b",
                "anal_pain": r"\b(?:anal pain|sharp pain|tearing pain|pain during stool)\b",
                "lump_or_prolapse": r"\b(?:lump|prolapse|protrud)\b",
                "hard_stools": r"\b(?:hard|lumpy|firm|normal|soft)\s+(?:stools?|poop)\b|\b(?:stools?|poop|poo)\s+(?:are|is)\s+(?:hard|lumpy|firm|normal|soft)\b",
                "straining": r"\b(?:strain|straining|push hard|pushing hard)\b",
                "incomplete_evacuation": r"\b(?:incomplete|not completely empty|not fully empty|still feel like i need to go)\b",
                "night_time_symptoms": r"\b(?:at night|wakes? me at night|when lying down)\b",
                "bowel_frequency_per_week": r"\b\d+(?:\.\d+)?\s*(?:bowel movements?|times?|motions?)\s*(?:per|a)\s*week\b",
                "bowel_frequency_per_day": r"\b\d+(?:\.\d+)?\s*(?:bowel movements?|times?|stools?|motions?)\s*(?:per|a)\s*day\b",
                "stool_form": r"\b(?:bristol|stool (?:type|form))\s*[1-7]\b",
                "meal_timing": r"\b(?:after meals?|after eating|right after eating|immediately after eating|\d+(?:\.\d+)?\s*(?:minutes?|hours?) later|when i lie down|at night|not related to meals?)\b",
                "symptom_onset_after_food": r"\b(?:right after|immediately after|\d+(?:\.\d+)?\s*(?:minutes?|hours?)\s+(?:later|after))\b",
                "timing_relation": r"\b(?:after meals?|after eating|when i lie down|at night|not related to meals?)\b",
                "bloating": r"\b(?:bloating|bloated|bloat)\b",
                "gas": r"\b(?:gas|gassy|flatulence|farting|passing\s+gas)\b",
                "constipation_explicit": r"\b(?:constipation|constipated)\b",
                "diarrhea": r"\b(?:diarrhea|diarrhoea|loose\s+(?:stools?|motions?)|watery\s+(?:stools?|poop))\b",
                "diarrhea_explicit": r"\b(?:diarrhea|diarrhoea|loose\s+(?:stools?|motions?)|watery\s+(?:stools?|poop))\b",
            }
            pat = patterns.get(f)
            return bool(pat and re.search(pat, normalized))

        # Restore every unrelated field unless it was explicitly volunteered.
        # This prevents generic numeric/keyword extraction from contaminating
        # the active question (e.g. "34 years" -> duration).
        if field and QUESTION_SCHEMA.get(field):
            for k, old_value in s.to_dict().items():
                if k in active_owned:
                    # The active question owns this slot. Generic extraction
                    # never wins over the contextual value (including None).
                    # Preserve the pre-turn active slots when the resolver
                    # is unresolved; `data` may already have been mutated by
                    # legacy handlers earlier in this method. Resolved turns
                    # retain the legacy handler's values until the validated
                    # resolver values are re-applied below.
                    preserve_prior = resolution_is_unresolved or (
                        resolution_is_partial and k not in resolved_active_values
                    )
                    merged_data[k] = (protected_active_values.get(k)
                                      if preserve_prior else data.get(k))
                    continue
                if explicit_field(k):
                    continue
                if old_value != merged_data.get(k):
                    merged_data[k] = old_value

        # Explicit negatives are first-class and can correct stale values, but
        # only when the user's message explicitly names the affected concept.
        if re.search(r"\b(?:no|not|never|without|don't|dont|do not|haven't|have not)\b", normalized):
            # Blood presence is owned by the contextual resolver and the active
            # bleeding question. Never overwrite it with a broad substring rule:
            # "No pain. Blood is bright red" contains both a negation and blood.
            if re.search(r"\b(?:weight loss|lost weight)\b", normalized) and re.search(r"\b(?:no|not|never|without|haven't|have not)\b.{0,35}\b(?:weight|lost weight)\b", normalized):
                merged_data["weight_loss"] = False

        if field == "hard_stools" and data.get("hard_stools") is False:
            merged_data["stool_form"] = None
            merged_data["secondary_symptoms"] = [
                x for x in (merged_data.get("secondary_symptoms") or [])
                if x != "hard stools"
            ]
        # Final ownership guard: explicit resolver values win over every
        # compatibility parser, including negation-sensitive legacy rules.
        if question_resolution.get("status") == "answered":
            for _key, _value in (question_resolution.get("values") or {}).items():
                if _key in merged_data:
                    merged_data[_key] = _value
                elif _key == "lump_or_prolapse":
                    merged_data["lump_or_prolapse"] = _value
                elif _key == "constipation_explicit":
                    merged_data["constipation_explicit"] = _value
                elif _key == "diarrhea_explicit":
                    merged_data["diarrhea_explicit"] = _value
                    merged_data["diarrhea"] = _value

        discarded = {}
        if field and QUESTION_SCHEMA.get(field):
            for k, value in merged.to_dict().items():
                if value not in (None, [], "", "unknown") and merged_data.get(k) != value:
                    discarded[k] = value
        if discarded:
            logger.info("[QUESTION][DISCARDED_UNRELATED_FACTS] field_count=%d", len(discarded))
        merged_state = SymptomState(**merged_data)
        merged_state.red_flags = derive_red_flags(merged_state)
        session.symptom_state = merged_state
        state_changes = {
            k: v for k, v in merged_state.to_dict().items()
            if s.to_dict().get(k) != v and v not in (None, [], "unknown")
        }
        if state_changes:
            logger.info("[QUESTION][STATE_UPDATE] fields=%s", sorted(state_changes))
        preserved = [
            k for k, v in s.to_dict().items()
            if k not in state_changes and v not in (None, [], "", "unknown")
            and getattr(session.symptom_state, k, None) == v
        ]
        if preserved:
            logger.info("[QUESTION][STATE_PRESERVE] preserved=%s", preserved)
        resolver_status = question_resolution.get("status") if isinstance(question_resolution, dict) else "unresolved"
        answered = resolver_status in {"answered", "partial"} and question_has_answer(session.symptom_state, field)
        answer_status = "answered" if answered else (
            "partial" if resolver_status in {"answered", "partial"} else resolver_status
        )
        resolver_source = contextual.get("_resolver_source", "fallback") if isinstance(contextual, dict) else "fallback"
        if answered:
            logger.info("[NLU][RESOLUTION_GUARD] status=answered fields_written=%s", list((question_resolution.get("values") or {}).keys()))
        confidence = float(
            (question_resolution or {}).get("confidence")
            or contextual.get("confidence")
            or 0.0
        )
        logger.info("[NLU][ANSWER] field=%s status=%s", field, answer_status)
        logger.info("[NLU][CONFIDENCE] type=%s value=%.2f",
                    "deterministic" if resolver_source == "deterministic" else "model",
                    confidence)
        logger.info("[QUESTION][RESOLUTION] field=%s status=%s confidence=%.2f",
                    field, answer_status, confidence)
        return QuestionResolution(
            field=field,
            answered=answered,
            values={
                k: getattr(session.symptom_state, k, None)
                for k in (QUESTION_SCHEMA.get(field).fields if QUESTION_SCHEMA.get(field) else set())
            },
            confidence=confidence,
            clarification_needed=not answered,
            answer_status=answer_status,
            source=resolver_source,
        )

    def _can_assess(self, session, screening):
        s = session.symptom_state
        if screening.get("action") == "urgent_medical_evaluation":
            return True
        if screening.get("pattern") == "Insufficiently characterized gut symptom pattern":
            return False

        branch = s.primary_symptom
        if s.blood_present:
            if s.blood_colour is None or s.sharp_pain_during_stool is None:
                return False
            if s.blood_colour == "bright_red" and s.sharp_pain_during_stool is False and s.lump_or_prolapse is None:
                return False
            return True

        if branch in ("constipation", "hard stools"):
            # Core constipation assessment: duration, bowel pattern, stool/strain,
            # incomplete evacuation, pain, bleeding, and key warning symptoms.
            required = [
                s.duration != "unknown", s.age is not None,
                s.bowel_frequency_per_week is not None,
                s.stool_form is not None and s.straining is not None,
                s.incomplete_evacuation is not None,
                s.abdominal_pain is not None,
                s.blood_present is not None,
                s.weight_loss is not None,
                s.vomiting is not None and s.fever is not None and s.abdominal_distension is not None,
                s.medications is not None,
            ]
            if not all(required):
                return False
            if s.blood_present:
                if s.blood_colour is None or s.sharp_pain_during_stool is None:
                    return False
                if s.blood_colour == "bright_red" and not s.sharp_pain_during_stool and s.lump_or_prolapse is None:
                    return False
            if s.duration != "unknown" and _duration_days(s.duration) and _duration_days(s.duration) >= 90:
                if s.abdominal_pain is True and s.pain_related_to_bowel_movement is None:
                    return False
            return True

        if branch == "piles":
            # Explicit piles/haemorrhoids can be assessed without forcing the
            # user through a constipation-style questionnaire. If bleeding is
            # present, retain the stricter differentiating questions.
            if s.blood_present:
                if s.blood_colour is None or s.sharp_pain_during_stool is None:
                    return False
                if s.blood_colour == "bright_red" and not s.sharp_pain_during_stool and s.lump_or_prolapse is None:
                    return False
            return s.duration != "unknown" and s.age is not None and s.blood_present is not None

        if branch == "diarrhea":
            return all([
                s.duration != "unknown", s.bowel_frequency_per_day is not None,
                s.abdominal_pain is not None, s.blood_present is not None,
                s.mucus is not None, s.fever is not None, s.weight_loss is not None,
            ])

        if branch in ("acidity", "heartburn"):
            return s.duration != "unknown" and s.weight_loss is not None and s.vomiting is not None

        if branch in ("piles", "anal fissures", "bleeding"):
            if s.blood_colour is None or s.sharp_pain_during_stool is None:
                return False
            if s.blood_colour == "bright_red" and not s.sharp_pain_during_stool and s.lump_or_prolapse is None:
                return False
            return True

        if branch == "stomach pain":
            return s.pain_location is not None and s.severity != "unknown" and s.vomiting is not None and s.fever is not None

        if branch in ("bloating", "gas"):
            # Do not end the assessment merely because three questions have
            # been asked. Bloating needs its branch-specific differentiators
            # (bowel pattern, food trigger, abdominal-pain relation, and stool
            # form) before a clinical pattern is finalized.
            return next_question(s) is None

        if branch == "indigestion":
            # Complete the upper-GI screening questions before diagnosis.
            return next_question(s) is None

        if branch == "food intolerance":
            # This branch has three dedicated questions; assess only after
            # those questions are answered or already known from the user's
            # messages.
            return next_question(s) is None

        return False

    @staticmethod
    def _product_screening(product, matched_phrase):
        return {
            "pattern": f"Product concern: {product['product_name']}",
            "likely_condition": f"Product concern: {matched_phrase}",
            "confidence": "high",
            "evidence": [f"user concern matched: {matched_phrase}"],
            "differentials": [],
            "action": "product_support",
            "product_allowed": True,
            "message": "This concern matches the product information in the Guttify product database.",
        }

    def _product_concern_result(self, session, text):
        matches = detect_product_concerns(text)

        # Resolve an answer to an earlier ambiguous product-concern question.
        if session.product_candidates and set(session.product_candidates) == {"Piles Pure", "Piloease Anal Care Spray"}:
            n = normalize(text)
            if set(session.product_candidates) == {"Piles Pure", "Piloease Anal Care Spray"}:
                if any(term in n for term in ("swelling", "swollen", "lump", "piles discomfort")):
                    matches = [("Piles Pure", "swelling")]
                elif any(term in n for term in ("burning", "itching", "itch", "irritation")):
                    matches = [("Piloease Anal Care Spray", "burning/itching/irritation")]

        if not matches and session.product_candidates:
            return None
        if matches:
            names = [name for name, _ in matches]
            # If a prior ambiguous concern exists, a new explicit concern
            # narrows it instead of restarting the conversation.
            if session.product_candidates:
                names = [n for n in names if n in session.product_candidates] or names
            unique = list(dict.fromkeys(names))
            session.product_candidates = unique
            if len(unique) == 1:
                product_name = unique[0]
                product = next((p for p in ALL_PRODUCTS if p.get("product_name") == product_name), None)
                if product:
                    matched = next((phrase for name, phrase in matches if name == product_name), product_name)
                    screening = self._product_screening(product, matched)
                    session.screening = screening
                    session.last_question = None
                    result = {"status": "RECOMMENDATION_FOUND", "message": "", "recommendations": [product], "product": product, "screening": screening, "safety": {"red_flag": False}}
                    return self._remember_recommendation(session, result)
            key = frozenset(unique)
            question = PRODUCT_CONCERN_QUESTIONS.get(key)
            if question and not session.product_concern_question_asked:
                session.product_concern_question_asked = True
                session.last_question = "product_concern"
                return {"status": "ASK", "message": question, "recommendations": [], "safety": {"red_flag": False}}
            # Non-clinical concern bundles (e.g. liver support / weight
            # management) are intentionally returned together, as configured
            # by the supplied business product map.
            products = [next((p for p in ALL_PRODUCTS if p.get("product_name") == name), None)
                         for name in unique]
            products = [p for p in products if p is not None]
            if products:
                session.screening = {
                    "likely_condition": "Product concern: " + ", ".join(unique),
                    "confidence": "high", "evidence": [phrase for _, phrase in matches],
                    "differentials": [], "action": "product_support",
                    "product_allowed": True,
                    "message": "These products match the concern in the Guttify product map; this is not a medical diagnosis.",
                }
                result = {"status": "RECOMMENDATION_FOUND", "message": "", "recommendations": products,
                          "product": products[0], "screening": session.screening, "safety": {"red_flag": False}}
                return self._remember_recommendation(session, result)
        return None

    @staticmethod
    def _clinical_symptom_present(text):
        primary, secondary = extract_symptoms(text)
        symptoms = {x for x in ([primary] if primary else []) + (secondary or [])}
        # Only symptoms that should force clinical/safety assessment block an
        # otherwise legitimate product-concern route. Routine constipation,
        # gas, bloating and diarrhea can coexist with an explicit product
        # concern without preventing that concern from being handled.
        return bool(symptoms & {
            "bleeding", "piles", "anal fissures",
            "stomach pain", "acidity", "heartburn", "indigestion", "vomiting"
        })

    @staticmethod
    def _is_explicit_assessment_start(text):
        """Recognize an explicit request to begin a fresh digestive assessment."""
        normalized = normalize(text)
        return bool(re.search(
            r"\b(?:start|begin|restart)\s+(?:a\s+)?(?:new\s+)?(?:gut[- ]health\s+|digestive\s+)?assessment\b"
            r"|\b(?:i want|i would like|please)\s+to\s+(?:start|begin)\s+(?:a\s+)?(?:new\s+)?(?:gut[- ]health\s+|digestive\s+)?assessment\b"
            r"|\bstart\s+over\s+with\s+(?:my\s+)?(?:gut|digestive)\s+assessment\b",
            normalized,
        ))

    @staticmethod
    def _reset_assessment_state(session):
        """Reset clinical progress while retaining the session-wide pregnancy product caution."""
        session.symptom_state = SymptomState()
        session.questions_asked = 0
        session.last_question = None
        session.awaiting_close = False
        session.ended = False
        session.diagnosis_complete = False
        session.screening = None
        session.product_candidates = []
        session.product_concern_question_asked = False
        session.last_product = None
        session.last_products = []
        session.clarification_question = None
        session.clarification_response = None
        session.clarification_count = 0
        session.awaiting_summary_confirmation = False
        session.summary_correction_mode = False
        session.summary_reviewed = False
        session.pregnancy_assessment_started = True

    @staticmethod
    def _is_summary_confirmation(text):
        return normalize(text) in {"yes", "yes correct", "correct", "looks correct", "that's correct", "that is correct", "confirm", "confirmed", "continue"}

    @staticmethod
    def _is_summary_rejection(text):
        return normalize(text) in {"no", "nope", "not correct", "incorrect", "that's wrong", "that is wrong", "needs correction", "change it"}

    def _apply_summary_correction(self, session, text):
        """Apply a clearly recognized customer correction, without diagnosing."""
        state = session.symptom_state
        before = state.to_dict()
        stool_form = extract_stool_form(text)
        duration = extract_duration(text)
        age = extract_age(text)
        severity = extract_severity(text)

        if stool_form in range(1, 8):
            state.stool_form = stool_form
            state.answered_unknown_fields = [
                field for field in (state.answered_unknown_fields or []) if field != "stool_form"
            ]
            state.asked_fields = list(dict.fromkeys((state.asked_fields or []) + ["stool_form"]))
            state.red_flags = derive_red_flags(state)
            return True
        elif duration and str(duration).lower() != "unknown":
            state.duration = duration
            return True
        elif age is not None:
            state.age = age
            return True
        elif severity not in (None, "unknown"):
            state.severity = severity
            return True
        else:
            # Use the existing deterministic NLU and explicit-negation
            # reconciliation for symptom corrections. Do not let this helper
            # make a diagnosis or select products.
            facts = extract_natural_facts(text, None, state)
            self._apply_volunteered_symptom_facts(session, text, facts)
            after_facts = session.symptom_state.to_dict()
            if after_facts == before:
                return False

        session.symptom_state.red_flags = derive_red_flags(session.symptom_state)
        return session.symptom_state.to_dict() != before

    def _summary_review_result(self, session):
        session.awaiting_summary_confirmation = True
        session.summary_correction_mode = False
        return {
            "status": "SUMMARY_REVIEW",
            "message": build_symptom_summary(session.symptom_state),
            "recommendations": [],
            "screening": None,
        }

    def _add_bristol_evidence(self, screening, state):
        """Add the selected Bristol type as transparent supporting evidence."""
        stool_form = getattr(state, "stool_form", None)
        if not isinstance(stool_form, int) or stool_form not in BRISTOL_LABELS:
            return screening
        line = f"Bristol Stool Chart type {stool_form}: {BRISTOL_LABELS[stool_form]}"
        evidence = screening.setdefault("evidence", [])
        if line not in evidence:
            evidence.append(line)
        return screening

    @staticmethod
    def _remember_recommendation(session, result):
        """Record a recommendation only after all active questions are resolved."""
        if session.pregnancy_lactation_caution:
            return {
                "status": "SAFETY_REVIEW",
                "message": "Your digestive assessment can continue, but because pregnancy or breastfeeding was mentioned, I won't recommend a Guttify product. Please discuss suitable options with your healthcare professional.",
                "recommendations": [],
                "safety": {
                    "safe_to_recommend": False,
                    "requires_doctor": False,
                    "red_flag": False,
                    "reasons": ["pregnancy/lactation product caution"],
                },
                "screening": result.get("screening") or session.screening,
            }
        if session.last_question and not question_has_answer(session.symptom_state, session.last_question):
            logger.error(
                "[QUESTION][INVARIANT_VIOLATION] recommendation_blocked field=%s",
                session.last_question,
            )
            return {
                "status": "ASK",
                "message": "I still need an answer to the question above before I can complete the assessment.",
                "recommendations": [],
                "screening": result.get("screening"),
                "safety": result.get("safety"),
            }
        recommendations = result.get("recommendations") or []
        if recommendations:
            session.last_product = recommendations[0]
        # A product-support recommendation closes the recommendation flow but
        # is not a clinical diagnosis. A recommendation produced from a completed
        # clinical screening keeps the assessment-complete flag. `awaiting_close`
        # independently prevents a later symptom from restarting either flow.
        session.awaiting_close = True
        screening = result.get("screening") or session.screening or {}
        session.diagnosis_complete = screening.get("action") != "product_support"
        return result

    def handle_message(self, sid, user_message, conversation_history=None):
        # Serialize mutations only within this session. Never hold the shared
        # map lock across extraction/network work: a slow Groq call must not
        # stall registration or conversations belonging to other customers.
        with self._lock:
            session_lock = self._session_locks.setdefault(sid, RLock())
        with session_lock:
            result = self._handle_message(sid, user_message, conversation_history)
            return self._attach_safety_metadata(self._get_session(sid), result)

    @staticmethod
    def _attach_safety_metadata(session, result):
        if not isinstance(result, dict) or result.get("status") != "SAFETY_REVIEW":
            return result
        safety = result.setdefault("safety", {})
        red_flag = bool(safety.get("red_flag") or session.symptom_state.red_flags)
        reason_code = safety.get("reason_code") or (
            "urgent_red_flag" if red_flag else "pregnancy_lactation_product_restriction"
        )
        assessment_scoped_review = red_flag or reason_code == "unanswered_safety_question"
        if red_flag:
            known = {item.get("reason") for item in session.safety_flag_provenance if isinstance(item, dict)}
            for reason in session.symptom_state.red_flags or safety.get("reasons", []):
                if reason in known:
                    continue
                session.safety_flag_provenance.append({
                    "reason": reason, "source": "confirmed_structured_answer",
                    "evidence": {"validated_state_reason": reason},
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "scope": "assessment", "assessment_id": None,
                })
            provenance = [item for item in session.safety_flag_provenance if item.get("reason") in (session.symptom_state.red_flags or safety.get("reasons", []))]
        else:
            provenance = [session.pregnancy_lactation_provenance] if session.pregnancy_lactation_provenance else []
        safety["reason_code"] = reason_code
        safety["scope"] = "assessment" if assessment_scoped_review else "customer"
        safety["flag_provenance"] = provenance
        screening = result.get("screening")
        if isinstance(screening, dict):
            screening["safety_reason_code"] = reason_code
            screening["flag_provenance"] = provenance
        logger.warning("event=safety_review reason_code=%s scope=%s sources=%s",
                       reason_code, safety["scope"],
                       ",".join(sorted({str(item.get("source", "unknown")) for item in provenance if isinstance(item, dict)})) or "unknown")
        return result

    def _handle_message(self, sid, user_message, conversation_history=None):
        session = self._get_session(sid)

        # Conversational asides do not answer a pending clinical question.
        # Handle these before NLU/state mutation and retain the pending slot.
        normalized_message = normalize(user_message)
        explanation_request = bool(re.fullmatch(
            r"(?:why(?:\s+(?:do you ask|do you need to know|is that|are you asking|did (?:that )?warning appear|did that appear|is this serious))?|"
            r"what does (?:that|the|that warning) mean|what do you mean|can you explain(?: that| the warning)?|"
            r"tell me more|is it serious|what should i do)",
            normalized_message,
        ))

        # SAFETY MUST ALWAYS RUN FIRST. A user can disclose an emergency after
        # diagnosis, after a product recommendation, or after saying thanks.
        safety = check_safety(user_message)
        if is_pregnancy_or_lactation(user_message):
            session.pregnancy_lactation_caution = True
            evidence = pregnancy_lactation_evidence(user_message)
            if evidence and not session.pregnancy_lactation_provenance:
                session.pregnancy_lactation_provenance = {
                    "reason": "pregnancy_lactation_product_restriction",
                    "source": "user_text_span", "evidence": evidence,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "scope": "customer", "assessment_id": None,
                }

        if safety["red_flag"]:
            # Persist the safety signal in structured session state. A later
            # downplaying message must not erase an earlier urgent disclosure.
            state_flags = list(getattr(session.symptom_state, "red_flags", []) or [])
            session.symptom_state.red_flags = list(dict.fromkeys(state_flags + list(safety.get("reasons") or [])))
            for reason in safety.get("reasons") or []:
                evidence = red_flag_evidence(user_message, reason)
                if evidence and not any(item.get("reason") == reason for item in session.safety_flag_provenance):
                    session.safety_flag_provenance.append({
                        "reason": reason, "source": "user_text_span", "evidence": evidence,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "scope": "assessment", "assessment_id": None,
                    })
            session.diagnosis_complete = True
            screening = {
                "pattern": "Red-flag presentation",
                "likely_condition": "Red-flag presentation",
                "confidence": "high",
                "evidence": safety["reasons"],
                "differentials": [],
                "action": "urgent_medical_evaluation",
                "product_allowed": False,
                "message": safety["message"],
            }
            session.screening = screening
            return {"status": "SAFETY_REVIEW", "message": safety["message"], "recommendations": [], "safety": safety, "screening": screening}

        # Safety flags remain active for the life of this conversation. Do not
        # resume routine assessment based on a later message that omits them.
        existing_flags = list(getattr(session.symptom_state, "red_flags", []) or [])
        if existing_flags:
            safety = {
                "safe_to_recommend": False, "requires_doctor": True,
                "red_flag": True, "reasons": existing_flags,
                "message": "A warning sign was reported earlier in this chat. Please seek prompt medical evaluation; I cannot continue routine product recommendations in this session.",
            }
            screening = session.screening or {
                "pattern": "Red-flag presentation", "likely_condition": "Red-flag presentation",
                "confidence": "high", "evidence": existing_flags, "differentials": [],
                "action": "urgent_medical_evaluation", "product_allowed": False,
                "message": safety["message"],
            }
            screening["action"] = "urgent_medical_evaluation"
            screening["product_allowed"] = False
            session.screening = screening
            session.diagnosis_complete = True
            if explanation_request:
                return {
                    "status": "SAFETY_REVIEW",
                    "message": "That warning appeared because you reported a symptom that can need prompt medical evaluation. It doesn't confirm a diagnosis, but it should be assessed by a healthcare professional. I can't provide product recommendations while this warning applies.",
                    "recommendations": [], "safety": safety, "screening": screening,
                }
            return {"status": "SAFETY_REVIEW", "message": safety["message"], "recommendations": [], "safety": safety, "screening": screening}

        if session.pregnancy_lactation_caution and not session.pregnancy_assessment_started:
            if self._is_explicit_assessment_start(user_message):
                self._reset_assessment_state(session)
                logger.info("[ASSESSMENT][EXPLICIT_RESTART] pregnancy_caution=true; product_recommendations=blocked")
                return {
                    "status": "ASK",
                    "message": "Of course. I can assess your digestive symptoms, but I still won't recommend Guttify products because pregnancy or breastfeeding was mentioned. What digestive symptom are you experiencing?",
                    "recommendations": [],
                    "safety": {
                        "safe_to_recommend": False,
                        "requires_doctor": False,
                        "red_flag": False,
                        "reasons": ["pregnancy/lactation product caution"],
                    },
                }
            caution = {
                "safe_to_recommend": False,
                "requires_doctor": False,
                "red_flag": False,
                "reasons": ["pregnancy/lactation product caution"],
                "message": "Because pregnancy or breastfeeding was mentioned, I won't recommend a Guttify product without appropriate professional guidance. If you'd still like a digestive symptom assessment, say 'start a digestive assessment'.",
            }
            return {"status": "SAFETY_REVIEW", "message": caution["message"], "recommendations": [], "safety": caution, "screening": session.screening}

        # A summary review pauses only non-urgent completion. Safety above always
        # has priority and may interrupt this gate. A confirmed summary is a
        # deterministic control action; it must not trigger a Groq/NLU call.
        summary_confirmation_turn = False
        if session.awaiting_summary_confirmation:
            if self._is_summary_confirmation(user_message):
                session.awaiting_summary_confirmation = False
                session.summary_correction_mode = False
                session.summary_reviewed = True
                session.last_question = None
                # Do not feed a bare confirmation like "yes" into generic NLU:
                # without an active question, it could be misread as positive
                # evidence for unrelated safety fields.
                user_message = "summary confirmed"
                summary_confirmation_turn = True
                logger.info("[SUMMARY][CONFIRMED] session=%s", str(sid)[:8])
            elif self._is_summary_rejection(user_message):
                session.awaiting_summary_confirmation = False
                session.summary_correction_mode = True
                return {
                    "status": "ASK",
                    "message": "What would you like to correct? You can update your symptom, duration, age, severity, or Bristol Stool Chart type (1–7). I will review the summary again before completing the assessment.",
                    "recommendations": [],
                }
            else:
                # Treat any non-confirmation as a proposed correction, but only
                # accept it if the deterministic correction parser recognizes it.
                if self._apply_summary_correction(session, user_message):
                    session.summary_reviewed = False
                    logger.info("[SUMMARY][CORRECTION_APPLIED] session=%s", str(sid)[:8])
                    if session.symptom_state.red_flags:
                        safety_result = {
                            "safe_to_recommend": False,
                            "requires_doctor": True,
                            "red_flag": True,
                            "reasons": session.symptom_state.red_flags,
                            "message": "Your correction includes a warning sign that needs medical evaluation. I won't recommend a product for these symptoms.",
                        }
                        screening = {
                            "pattern": "Red-flag presentation",
                            "likely_condition": "Red-flag presentation",
                            "confidence": "high",
                            "evidence": list(session.symptom_state.red_flags),
                            "differentials": [],
                            "action": "urgent_medical_evaluation",
                            "product_allowed": False,
                            "message": safety_result["message"],
                        }
                        session.screening = screening
                        session.diagnosis_complete = True
                        return {"status": "SAFETY_REVIEW", "message": safety_result["message"], "recommendations": [], "safety": safety_result, "screening": screening}
                    return self._summary_review_result(session)
                return {
                    "status": "ASK",
                    "message": "I couldn't identify the correction clearly, so I haven't changed your answers. Please specify a Bristol type from 1 to 7, a duration such as '3 weeks', an age, a severity, or the symptom you want to correct.",
                    "recommendations": [],
                }

        if session.summary_correction_mode:
            if self._apply_summary_correction(session, user_message):
                session.summary_correction_mode = False
                session.summary_reviewed = False
                logger.info("[SUMMARY][CORRECTION_APPLIED] session=%s", str(sid)[:8])
                if session.symptom_state.red_flags:
                    screening = evaluate_screening(session.symptom_state)
                    session.screening = screening
                    session.diagnosis_complete = True
                    return {"status": "SAFETY_REVIEW", "message": screening["message"], "recommendations": [], "screening": screening,
                            "safety": {"safe_to_recommend": False, "requires_doctor": True, "red_flag": True, "reasons": session.symptom_state.red_flags, "message": screening["message"]}}
                return self._summary_review_result(session)
            return {
                "status": "ASK",
                "message": "I couldn't identify that correction clearly, and I haven't changed your answers. Please give a specific correction, such as 'Bristol type 4' or 'duration 3 weeks'.",
                "recommendations": [],
            }

        if session.ended:
            return {"status": "SESSION_ENDED", "message": SESSION_ENDED_MESSAGE, "recommendations": []}

        if explanation_request and session.last_question:
            why = "I'm asking to understand the pattern and duration of your symptoms. That helps the assessment follow the relevant questions and avoid acting on assumptions. You can answer in your own words."
            return {"status": "ANSWER", "message": why, "recommendations": []}

        general_question = bool(re.search(
            r"\b(what will you do|what can you help me with|what can you help with|"
            r"how does (?:this chatbot|gutgpt) work|what is gutgpt|explain your process|"
            r"why are you asking (?:me )?(?:these|so many) questions|do you actually understand digestive problems|"
            r"can you help me understand my symptoms|can you help with digestive problems)\b",
            normalized_message,
        ))
        if general_question:
            if "why are you asking" in normalized_message:
                reply = "I'm asking these questions to understand your symptoms properly. This helps me distinguish between different digestive concerns and avoid suggesting something unsuitable. You can answer naturally, in your own words."
            else:
                reply = "I can help you understand digestive symptoms, ask relevant follow-up questions, identify warning signs that may need medical attention, and share information from the Guttify product catalog. I don't provide a medical diagnosis. Describe what's bothering you and I'll guide you from there."
            return {"status": "ANSWER", "message": reply, "recommendations": []}

        # Thank-you messages are acknowledgements, not a reason to lock the
        # conversation. Keep the session usable after "thank you", "thanks",
        # "thx", "appreciate it", etc.
        if is_gratitude_only(user_message):
            return {
                "status": "ACKNOWLEDGEMENT",
                "message": "You're welcome! If you have another question, just ask.",
                "recommendations": [],
            }

        if session.awaiting_close and is_satisfied_closing(user_message):
            session.ended = True
            return {"status": "SESSION_ENDED", "message": random_closing_response(), "recommendations": []}

        if is_greeting(user_message):
            return {"status": "GREETING", "message": random_greeting_response(), "recommendations": []}

        # Resolve explicit product names and product-detail follow-ups before
        # assessment continuation/relevance checks. Domain words such as
        # "ingredients" and "instructions" must not make a valid follow-up
        # look like a new, irrelevant standalone request.
        named = find_named_product(user_message)
        if named and not self._clinical_symptom_present(user_message):
            session.last_product = named
            # A product question can temporarily change topics during an
            # assessment. Keep its active question and clinical state intact
            # so the user can return to the assessment on the next turn.
            if not session.last_question and not session.symptom_state.primary_symptom:
                session.awaiting_close = True
            return {"status": "PRODUCT_INFO_FOUND", "message": "", "product": named,
                    "recommendations": [named], "screening": None}

        if session.last_products and re.search(r"\b(first|1st|number one|no\. ?1)\b", normalize(user_message)):
            session.last_product = session.last_products[0]
            return {"status": "PRODUCT_INFO_FOUND", "message": "", "product": session.last_product,
                    "recommendations": [session.last_product], "screening": None}

        detail_followup = bool(re.search(
            r"\b(instruction|usage|dosage|dose|take|use|ingredient|benefit|warning|precaution|side effect|more detail|tell me more|more information|elaborate|what else|how does it work|what is it for|what does it do|purpose)\w*\b",
            normalize(user_message),
        ))
        if detail_followup and session.last_product:
            return {"status": "PRODUCT_INFO_FOUND", "message": "", "product": session.last_product,
                    "recommendations": [session.last_product], "screening": None}

        # Product discovery is browsing, not symptom-based recommendation.
        # Return only active records loaded from the existing catalog.
        normalized = normalize(user_message)
        discovery = bool(re.search(
            r"\b(products|what (?:do you have|do you sell|is available|can i have|can help with)|what you have|what i can have|show me|which .* available|do you have anything for)\b",
            normalized,
        ))
        if discovery:
            active_products = [p for p in ALL_PRODUCTS if p.get("status") == "active"]
            mentioned_symptoms = [
                symptom
                for product in active_products
                for symptom in product.get("symptoms", [])
                if normalize(symptom) in normalized
            ]
            if mentioned_symptoms:
                terms = set(mentioned_symptoms)
                session.last_products = [
                    p for p in active_products
                    if terms.intersection(normalize(s) for s in p.get("symptoms", []))
                ]
            else:
                session.last_products = active_products
            categories = list(dict.fromkeys(p.get("category", "") for p in session.last_products if p.get("category")))
            return {"status": "PRODUCT_DISCOVERY", "message": (
                "Available product categories: " + ", ".join(categories) + ". Products: "
                + "; ".join(p.get("product_name", "") for p in session.last_products)
                + ". Would you like general digestive support, or are you experiencing a specific symptom?"
            ), "products": session.last_products, "recommendations": []}

        # Short noisy input stays deterministic and cheap. Otherwise use the
        # contextual intent router for questions and symptom phrases that the
        # canonical symptom parser cannot confidently recognize.
        if not session.last_question and is_gibberish(user_message):
            return {"status": "GIBBERISH", "message": random_gibberish_response(), "recommendations": []}

        recognized_primary, recognized_secondary = extract_symptoms(user_message)
        explicit_symptom_report = bool(re.search(
            r"\b(?:i have|i've got|i am having|i'm having|i experience|i've been|"
            r"i notice|there is|there's|my .{0,35}(?:feels?|hurts?|is|has))\b",
            normalized,
        ))
        educational_question_prefix = bool(re.match(
            r"^(?:why\b|what (?:causes|is|are|does|do|happens|is the difference)\b|how (?:does|do|can|is)\b)",
            normalized,
        ))
        if educational_question_prefix:
            explicit_symptom_report = False
        explicit_correction = bool(re.search(
            r"\b(?:actually|i meant|correction|to clarify)\b.*\b(?:no|not|don't|dont|do not|doesn't|does not|isn't|is not|haven't|have not)\b",
            normalized,
        ))
        question_like = "?" in user_message or bool(re.match(
            r"^(?:what|why|how|can|could|is|are|which|should|would|tell me|explain|do you|does it|does this)\b",
            normalized,
        ))
        if not session.last_question and re.fullmatch(r"(?:yes|yeah|yep|yup|no|nope|nah|okay|ok|sure)", normalized):
            if session.last_products:
                clarification = "Do you mean you'd like general information about the products I listed, or would you like to discuss a digestive symptom?"
            else:
                clarification = "What would you like me to respond to? You can ask about digestion, describe a symptom, or name a Guttify product."
            return {"status": "ASK", "message": clarification, "recommendations": []}
        active_answer_status = None
        if session.last_question:
            active_answer_status = resolve_against_active_question(
                session.last_question, user_message, state=session.symptom_state,
            ).get("status")
        should_classify = (
            question_like and not explicit_symptom_report
            and (not session.last_question or active_answer_status in {"unresolved", "clarification_needed"})
        ) or (
            not session.last_question and not summary_confirmation_turn
            and not explicit_correction and not recognized_primary and not recognized_secondary
        )
        if summary_confirmation_turn:
            should_classify = False
        if detect_product_concerns(user_message):
            should_classify = False
        if (
            question_like and not (recognized_primary or recognized_secondary)
            and re.search(r"\b(?:what should i (?:take|do)|what do you recommend|which product|which one is better)\b", normalized)
        ):
            return {"status": "ASK", "message": "I can guide you through the existing symptom assessment before discussing whether any product is suitable. What digestive symptoms are you experiencing?", "recommendations": []}

        # General-knowledge topics are routed through the constrained assistant
        # instead of a brittle hard-coded keyword denylist. Clinical/safety
        # gates above and below remain authoritative.

        route = classify_intent(
            user_message, history=conversation_history,
            pending_question=session.last_question,
        ) if should_classify and enabled("GUTGPT_CONVERSATION_ROUTER_ENABLED", True) else None

        if (
            route is None and not session.last_question and not explicit_correction
            and not (recognized_primary or recognized_secondary)
            and re.search(r"\b(?:digestive problem|digestive issue|digestion (?:problem|issue|trouble)|stomach (?:isn't|is not|doesn't|does not) feel(?:ing)? right|stomach feels? (?:off|uncomfortable|heavy)|something is wrong with my digestion|(?:experience )?discomfort after eating|uncomfortable after eating)\b", normalized)
        ):
            return {"status": "ASK", "message": OPEN_SYMPTOM_REPLY, "recommendations": []}

        if route:
            intent = route["intent"]
            if intent == "general_gut_health_question":
                answer = answer_general_question(
                    user_message, history=conversation_history,
                    product_names=[p.get("product_name") for p in ALL_PRODUCTS],
                )
                return {"status": "ANSWER", "message": answer, "recommendations": []}
            if intent == "general_knowledge_question" and enabled("GUTGPT_GENERAL_KNOWLEDGE_ENABLED", True):
                answer = answer_general_question(user_message, history=conversation_history,
                    product_names=[p.get("product_name") for p in ALL_PRODUCTS])
                return {"status": "ANSWER", "message": answer, "recommendations": []}
            if intent == "company_information" and enabled("GUTGPT_COMPANY_KNOWLEDGE_ENABLED", True):
                answer = answer_company_question(user_message, history=conversation_history, products=ALL_PRODUCTS)
                return {"status": "ANSWER", "message": answer, "recommendations": []}
            if intent == "research_summary" and enabled("GUTGPT_RESEARCH_ASSISTANT_ENABLED", True):
                answer = answer_research_question(user_message, history=conversation_history)
                return {"status": "ANSWER", "message": answer, "recommendations": []}
            if intent == "unrelated_question":
                return {"status": "ANSWER", "message": SCOPE_REPLY, "recommendations": []}
            if intent == "casual_conversation":
                return {"status": "ANSWER", "message": "I'm doing well, thanks for asking. What would you like to know about digestion or gut health?", "recommendations": []}
            if intent == "product_information":
                return {"status": "ANSWER", "message": "I can share information from the verified Guttify product catalog. Which product would you like to ask about?", "recommendations": []}
            if intent == "product_recommendation_request" and not (recognized_primary or recognized_secondary):
                return {"status": "ASK", "message": "I can guide you through the existing symptom assessment before discussing whether any product is suitable. What digestive symptoms are you experiencing?", "recommendations": []}
            if intent == "medical_safety_concern":
                return {"status": "ANSWER", "message": "I can't diagnose or advise on medication. If your symptoms are severe, worsening, or worrying you, please contact a healthcare professional. If you tell me what you're experiencing, I can continue the structured symptom assessment.", "recommendations": []}
            if intent == "digestive_problem" and not session.symptom_state.primary_symptom and not (recognized_primary or recognized_secondary):
                return {"status": "ASK", "message": OPEN_SYMPTOM_REPLY, "recommendations": []}

        elif question_like and re.search(r"\b(gut|digest|stomach|bowel|gas|bloat|acidity|heartburn|constipat|indigestion|ib s|ibs|food|meal)\w*\b", normalized):
            # When routing is unavailable, keep an obvious educational
            # question inside the allowed domain and use a safe answer fallback.
            return {"status": "ANSWER", "message": SAFE_GENERAL_FALLBACK, "recommendations": []}

        elif route is None and question_like and not explicit_symptom_report:
            return {"status": "ANSWER", "message": SCOPE_REPLY, "recommendations": []}

        # An explicit unsupported symptom should not be mistaken for a
        # digestive assessment merely because it was passed to the bot.
        if re.search(r"\b(?:back pain|headache|migraine)\b", normalized) and not self._clinical_symptom_present(user_message):
            return {"status": "ANSWER", "message": SCOPE_REPLY, "recommendations": []}
        # A pending questionnaire question owns the turn. Numeric/short answers
        # such as "34 years", "7", "no", and "2.5 litres" must never be rejected
        # by the generic gibberish detector before contextual resolution.
        # A final diagnosis is a terminal state for the clinical pipeline.
        # Do not re-run symptom extraction, questionnaire questions, or
        # diagnosis on later messages in the same session. Product-name
        # lookups remain available as non-diagnostic follow-ups.
        if session.diagnosis_complete:
            named_after_diagnosis = find_named_product(user_message)
            if named_after_diagnosis:
                session.last_product = named_after_diagnosis
                return {
                    "status": "PRODUCT_INFO_FOUND",
                    "message": "",
                    "product": named_after_diagnosis,
                    "recommendations": [named_after_diagnosis],
                    # Product follow-ups are informational, not a continuation
                    # of the clinical assessment. Do not pass the old screening
                    # result to the response layer.
                    "screening": None,
                }
            return {
                "status": "DIAGNOSIS_COMPLETE",
                "message": "Your assessment is already complete. I won't start a new diagnosis in this chat. If you want information about a Guttify product or the assessment already given, ask me directly.",
                "recommendations": [],
                "screening": session.screening,
            }

        named = find_named_product(user_message)

        # A recommendation has already been delivered. Do not feed subsequent
        # messages back into diagnosis/recommendation matching: doing so can
        # reproduce the same product block for messages such as "Piles Pure",
        # "stop", or a short follow-up. Explicit product names stay in the
        # product-information path; other follow-ups use the last approved
        # product without changing the clinical assessment.
        if session.awaiting_close:
            if named:
                session.last_product = named
                return {
                    "status": "PRODUCT_INFO_FOUND",
                    "message": "",
                    "product": named,
                    "recommendations": [named],
                    # Keep this product-only. The previous clinical assessment
                    # must not be attached to a product-information answer.
                    "screening": None,
                }

            # Once a recommendation has been delivered, this session is
            # finished from the clinical/recommendation pipeline's perspective.
            # Do NOT allow a later symptom (e.g. "constipation") to restart
            # diagnosis. Previously this branch only blocked non-clinical text,
            # so a new symptom could re-enter the questionnaire and set
            # diagnosis_complete=True, after which every later message was
            # incorrectly treated as a completed diagnosis.
            #
            # Product-name lookups above remain available. For ordinary
            # product follow-ups ("what is it for?", "how do I take it?"),
            # keep using the last approved product. Only a new clinical/domain
            # symptom is blocked.
            if not has_domain_overlap(user_message) and session.last_product:
                return {
                    "status": "PRODUCT_INFO_FOUND",
                    "message": "",
                    "product": session.last_product,
                    "recommendations": [session.last_product],
                    "screening": None,
                }

            return {
                "status": "RECOMMENDATION_COMPLETE",
                "message": "That recommendation has already been provided. If you want information about a Guttify product, ask me about the product by name. To discuss a new health concern, please start a new chat.",
                "recommendations": [],
                "screening": None,
            }

        # A named product request is a shortcut only when the user is not
        # also reporting a clinical symptom that needs assessment.
        if named and not session.symptom_state.primary_symptom and not self._clinical_symptom_present(user_message):
            session.awaiting_close = True
            return {"status": "PRODUCT_INFO_FOUND", "message": "", "product": named, "recommendations": [named]}

        # Contextual NLU runs before relevance routing. An active question has
        # priority over generic domain/product classification.
        pending_question = session.last_question
        if summary_confirmation_turn:
            # The customer has confirmed the deterministic summary. Do not call
            # the model to classify a control phrase, and do not derive new
            # clinical facts from it. Continue through the existing rule engine
            # and questionnaire-completeness gates below.
            nlu_facts = {
                "intent": "answer_question",
                "confidence": 1.0,
                "_resolver_source": "deterministic_control",
                "_answer_status": "answered",
                "_question_resolution": {
                    "status": "answered", "values": {},
                    "confidence": 1.0, "source": "deterministic_control",
                },
            }
            logger.info("[NLU][MODEL_CALL] called=false reason=summary_confirmation_control")
        else:
            nlu_facts = self._run_nlu(session, user_message, conversation_history)

        # Keep the existing deterministic parser as a second layer.
        if pending_question:
            # Preserve explicitly volunteered symptoms without allowing them to
            # answer or overwrite the active questionnaire field.
            self._apply_volunteered_symptom_facts(session, user_message, nlu_facts)
            # Active-question resolution remains the authority for the asked slot.
            resolution = self._apply_answer(session, user_message, nlu_facts)
            # Reconcile explicit symptom mentions after legacy question parsers;
            # they may otherwise reintroduce a generic positive from a negated phrase.
            self._apply_volunteered_symptom_facts(session, user_message, nlu_facts)
            session.symptom_state.red_flags = derive_red_flags(session.symptom_state)
            logger.info(
                "[QUESTION][CONTEXTUAL_FACTS] %s",
                sorted(resolution.values) if resolution else [],
            )
            logger.info(
                "[QUESTION][RESOLUTION] field=%s answered=%s confidence=%.2f clarification_needed=%s",
                pending_question,
                resolution.answered if resolution else False,
                resolution.confidence if resolution else 0.0,
                resolution.clarification_needed if resolution else True,
            )

            # Safety overrides question completeness: a newly extracted red
            # flag must stop the assessment even when a multi-part question
            # still has unanswered subfields.
            if session.symptom_state.red_flags:
                safety = {
                    "safe_to_recommend": False,
                    "requires_doctor": True,
                    "red_flag": True,
                    "reasons": session.symptom_state.red_flags,
                    "message": "This needs medical evaluation rather than only self-treatment. I won't recommend a Guttify product for these symptoms.",
                }
                screening = {
                    "pattern": "Red-flag presentation",
                    "likely_condition": "Red-flag presentation",
                    "confidence": "high",
                    "evidence": session.symptom_state.red_flags,
                    "differentials": [],
                    "action": "urgent_medical_evaluation",
                    "product_allowed": False,
                    "message": safety["message"],
                }
                return {"status": "SAFETY_REVIEW", "message": safety["message"],
                        "recommendations": [], "safety": safety, "screening": screening}

            # The resolver owns answerability. Never infer completion from
            # stale state when the current turn was unresolved/ambiguous.
            resolution_status = resolution.answer_status if resolution else "unresolved"
            if resolution_status in {"unresolved", "clarification_needed"}:
                session.last_question = pending_question
                logger.info("[NLU][RESOLUTION_GUARD] status=%s facts_written=0", resolution_status)
                # Continue into the existing clarification response below.

            # Do not consume a question merely because it was displayed. If
            # the response did not answer that question, keep the context
            # active and ask for clarification instead of skipping a required
            # clinical field or declaring a diagnosis prematurely.
            if resolution_status in {"unresolved", "clarification_needed"} or not question_has_progressed(session.symptom_state, pending_question):
                session.last_question = pending_question
                # Use a focused clarification when the user answered only
                # part of a multi-concept question. Repeating the entire
                # question ("I do have some pain" -> repeat the same pain
                # question) creates a conversational loop and does not tell
                # the user which missing concept is unresolved.
                focused_clarifications = {}
                if pending_question == "pain":
                    if session.symptom_state.abdominal_pain is True and session.symptom_state.pain_related_to_bowel_movement is None:
                        focused_clarifications["pain"] = "Does the pain improve, worsen, or change after you have a bowel movement?"
                    elif session.symptom_state.abdominal_pain is None and session.symptom_state.pain_related_to_bowel_movement is None:
                        focused_clarifications["pain"] = "Do you have recurring abdominal pain, and if so, does it improve, worsen, or change after a bowel movement?"
                if pending_question == "bloating_pain":
                    if session.symptom_state.abdominal_pain is True and session.symptom_state.pain_related_to_bowel_movement is None:
                        focused_clarifications["bloating_pain"] = "Does the abdominal pain improve, worsen, or change after a bowel movement?"
                    elif session.symptom_state.bloating is True and session.symptom_state.abdominal_pain is None:
                        focused_clarifications["bloating_pain"] = "Do you also have recurring abdominal pain, and if so, does it change after a bowel movement?"
                if pending_question == "timing":
                    # A bare yes/no cannot identify which timing option the
                    # user means. Never repeat the same multi-option question
                    # verbatim; explicitly request the missing choice.
                    focused_clarifications["timing"] = (
                        "Which is it: after meals/eating, when lying down, or at night? "
                        'You can also give the timing, for example, "10 minutes" or "immediately".'
                    )
                # Use the exact question text associated with the pending field.
                question_texts = {
                    "duration": "How long has this been happening?",
                    "age": "What is your age?",
                    "weight_loss": "Have you lost any significant weight?",
                    "weight_loss_duration": "Have you lost any significant weight?",
                    "blood": "Have you noticed any bleeding or blood around/after a bowel movement?",
                    "blood_colour": "Is the blood bright/fresh red, or dark/black/tarry?",
                    "blood_location": "If it is bright red, is it on tissue, dripping into the toilet, or mixed into the stool?",
                    "anal_pain": "Is there sharp or tearing pain during or just after a bowel movement?",
                    "lump": "Is there a lump or something protruding from the anus?",
                    "stool_straining": "Are your stools hard or lumpy, and do you need to strain to pass them?",
                    "constipation": "Do you have hard stools or strain when passing stool?",
                    "bowel_frequency": "About how many bowel movements do you usually have in a week? A rough estimate is fine.",
                    "daily_frequency": "About how many loose or watery stools do you have on a typical day? A number or rough range is fine.",
                    "blood_mucus": "Do you have blood or mucus in the stool?",
                    "vomiting_fever": "Any vomiting or fever?",
                    "vomiting_fever_swelling": "Any repeated vomiting, fever, or severe abdominal swelling?",
                    "reflux": "Do you get a sour taste or acid/food coming back up?",
                    "timing": "How soon after eating does it start?",
                    "triggers": "Do tea/coffee, spicy, oily, or particular foods trigger it?",
                    "food_trigger": "Is it repeatedly linked to dairy, wheat, beans/lentils, or another particular food?",
                    "food_relation": "Is it triggered or worsened by meals?",
                    "trigger": "Which food triggers it, and does it happen repeatedly after the same food?",
                    "pain_relation": "Is the pain more related to meals or to bowel movements?",
                    "bowel_pattern": "Do you mainly have constipation, diarrhea, or both at different times?",
                    "symptoms": "What happens after the food: bloating, gas, diarrhea, cramps, constipation, or something else?",
                }
                missing_component = next_question_component(pending_question, session.symptom_state)
                if missing_component:
                    session.active_question_component, question_text = missing_component
                else:
                    session.active_question_component = None
                    question_text = focused_clarifications.get(
                        pending_question,
                        question_texts.get(pending_question, "Could you answer the question above in a little more detail?")
                    )
                normalized_reply = normalize(user_message)
                repeated = (
                    session.clarification_question == pending_question
                    and session.clarification_response == normalized_reply
                )
                session.clarification_question = pending_question
                session.clarification_response = normalized_reply
                session.clarification_count += 1
                logger.info(
                    "[QUESTION][BLOCK] field=%s reason=%s action=ASK_CLARIFICATION",
                    pending_question,
                    "repeated_nonanswer" if repeated else "answer_not_understood",
                )
                logger.info("[NLU] unanswered_question field=%s; preserving context", pending_question)
                clarification_intro = (
                    "I still need an answer to that specific part. "
                    if repeated else "I want to make sure I understood that. "
                )
                return {
                    "status": "ASK",
                    "message": _with_diarrhea_guidance(f"{clarification_intro}{question_text}", session.symptom_state, session=session),
                    "recommendations": [],
                    "safety": safety,
                }
            session.last_question = None
            session.active_question_component = None
            session.clarification_question = None
            session.clarification_response = None
            session.clarification_count = 0
        else:
            session.symptom_state = merge_state(session.symptom_state, user_message, [])
            self._apply_nlu_facts(session, nlu_facts)
            self._apply_volunteered_symptom_facts(session, user_message, nlu_facts)

        session.symptom_state.red_flags = derive_red_flags(session.symptom_state)

        # Structured questionnaire answers can reveal a warning sign after the
        # raw-message safety check has already run. Never continue to product
        # matching once those facts are present.
        if session.symptom_state.red_flags:
            safety = {
                "safe_to_recommend": False,
                "requires_doctor": True,
                "red_flag": True,
                "reasons": session.symptom_state.red_flags,
                "message": "This needs medical evaluation rather than only self-treatment. I won't recommend a Guttify product for these symptoms.",
            }
            screening = {
                "pattern": "Red-flag presentation",
                "likely_condition": "Red-flag presentation",
                "confidence": "high",
                "evidence": session.symptom_state.red_flags,
                "differentials": [],
                "action": "urgent_medical_evaluation",
                "product_allowed": False,
                "message": safety["message"],
            }
            return {"status": "SAFETY_REVIEW", "message": safety["message"], "recommendations": [], "safety": safety, "screening": screening}

        # Explicit product concerns should not be lost just because the same
        # message also contains a gut symptom (for example, "bloating and dull
        # skin"). Keep this routing small: only the existing product-concern
        # aliases can activate it.
        if pending_question == "product_concern":
            product_result = self._product_concern_result(session, user_message)
            if product_result:
                return product_result
        elif not pending_question and detect_product_concerns(user_message):
            # An active clinical/questionnaire slot owns this turn; product
            # aliases must never short-circuit the remaining assessment.
            # Product concerns can coexist with low-risk gut symptoms (for
            # example, "bloating and dull skin"), but a clinically relevant
            # symptom must not be bypassed by the product router.
            if not self._clinical_symptom_present(user_message):
                product_result = self._product_concern_result(session, user_message)
                if product_result:
                    return product_result

        # Never use product/domain keyword overlap to judge an answer while an
        # assessment is active. "2 days" is a valid answer to a duration
        # question even though it contains no symptom/product keyword.
        nlu_intent = nlu_facts.get("intent") if isinstance(nlu_facts, dict) else None
        if (
            not session.symptom_state.primary_symptom
            and not has_domain_overlap(user_message)
            and nlu_intent not in {"assessment", "answer_question", "new_symptom"}
            and not session.last_question
        ):
            if session.clarification_count >= 3:
                return {
                    "status": "ANSWER",
                    "message": "That's okay—you don't need to know the exact symptom name. Whenever you're ready, tell me what feels different or uncomfortable, and I'll help from there.",
                    "recommendations": [],
                }
            session.clarification_count += 1
            return {
                "status": "ASK",
                "message": "I may have missed what you mean. Could you say a little more? I can help with digestive health or Guttify product information.",
                "recommendations": [],
            }

        if (
            not session.symptom_state.primary_symptom
            and nlu_intent in {"assessment", "answer_question", "new_symptom"}
            and not has_domain_overlap(user_message)
        ):
            return {
                "status": "ASK",
                "message": "I'm not completely sure I understood the main symptom. Could you tell me whether you're mainly experiencing pain, bleeding, itching, constipation, loose stools, bloating, acidity, or another digestive symptom?",
                "recommendations": [],
            }

        if session.last_question and not question_has_answer(session.symptom_state, session.last_question):
            logger.error(
                "[QUESTION][BLOCK] unresolved_active_question_before_diagnosis field=%s",
                session.last_question,
            )
            return {
                "status": "ASK",
                "message": _with_diarrhea_guidance(
                    "I still need an answer to the question above before I can complete the assessment.",
                    session.symptom_state,
                    session=session,
                ),
                "recommendations": [],
                "safety": safety,
            }

        screening = evaluate_screening(session.symptom_state)
        session.screening = screening

        # Questionnaire completeness is the final gate before a normal
        # clinical assessment. Every branch must finish its own required
        # screening questions; do not let a branch-specific _can_assess()
        # shortcut diagnose early. Safety/urgent cases are handled above and
        # are deliberately allowed through immediately.
        if screening.get("action") != "urgent_medical_evaluation" and session.symptom_state.primary_symptom:
            pending = next_question(session.symptom_state)
            if pending:
                name, question_text = pending
                if name not in session.symptom_state.asked_fields:
                    session.symptom_state.asked_fields.append(name)
                session.last_question = name
                session.questions_asked += 1
                logger.info("[QUESTION] next=%s safety_flag_count=%d", name, len(session.symptom_state.red_flags or []))
                return {"status": "ASK", "message": _with_diarrhea_guidance(question_text, session.symptom_state, session=session), "recommendations": [], "safety": safety}

        if self._can_assess(session, screening):
            screening = self._add_bristol_evidence(screening, session.symptom_state)
            session.screening = screening
            if screening.get("action") != "urgent_medical_evaluation" and not session.summary_reviewed:
                return self._summary_review_result(session)
            # Reaching an assessable clinical pattern is the end of the
            # diagnostic pipeline for this session. This MUST be set before
            # product evaluation as well as for diagnosis-only outcomes;
            # otherwise a recommendation response can be followed by another
            # symptom message that re-enters the questionnaire and generates
            # another long diagnosis.
            session.diagnosis_complete = True

            if not screening.get("product_allowed"):
                session.diagnosis_complete = True
                return {"status": "DIAGNOSIS", "message": _with_diarrhea_guidance(screening["message"], session.symptom_state, screening, session), "recommendations": [], "safety": safety, "screening": screening}

            allowed = _approved_names_for_screening(screening, session.symptom_state)
            result = evaluate_product(session.symptom_state, user_message, allowed_names=allowed, match_context=screening.get("pattern"))
            result = _filter_approved_products(result, screening, session.symptom_state)
            result["screening"] = screening
            result["safety"] = safety
            if result.get("status") in ("RECOMMENDATION_FOUND", "AMBIGUOUS"):
                return self._remember_recommendation(session, result)
            # Clinical assessment must never disappear merely because product
            # data is incomplete.
            session.diagnosis_complete = True
            return {"status": "DIAGNOSIS", "message": _with_diarrhea_guidance(screening["message"], session.symptom_state, screening, session), "recommendations": [], "safety": safety, "screening": screening}

        if session.questions_asked < MAX_QUESTIONS:
            q = next_question(session.symptom_state)
            if q:
                name, question_text = q
                if name not in session.symptom_state.asked_fields:
                    session.symptom_state.asked_fields.append(name)
                session.last_question = name
                session.questions_asked += 1
                logger.info("[QUESTION] next=%s safety_flag_count=%d", name, len(session.symptom_state.red_flags or []))
                return {"status": "ASK", "message": _with_diarrhea_guidance(question_text, session.symptom_state, session=session), "recommendations": [], "safety": safety}

        safety_unknowns = set(
            (session.symptom_state.answered_unknown_fields or [])
            + (session.symptom_state.refused_fields or [])
        ) & {
            "blood", "bleeding", "blood_present", "blood_colour", "blood_location",
            "blood_mucus", "mucus", "anal_pain", "sharp_pain_during_stool", "lump",
            "lump_or_prolapse", "night_weight_fever", "night_time_symptoms", "weight_loss",
            "vomiting_fever", "vomiting_fever_swelling", "swallowing", "weight_swallow",
            "fever", "vomiting", "persistent_vomiting", "vomiting_blood",
            "difficulty_swallowing", "abdominal_distension",
        }
        if safety_unknowns:
            message = (
                "I can't complete a safe symptom assessment because one or more warning-sign "
                "questions were left unanswered. I have not treated those answers as negative "
                "or made a diagnosis. Please discuss your symptoms with a healthcare professional."
            )
            screening = {
                "pattern": "Assessment incomplete — safety information unknown",
                "likely_condition": "Assessment incomplete",
                "confidence": "low",
                "evidence": [f"Unanswered safety question: {field}" for field in sorted(safety_unknowns)],
                "differentials": [],
                "action": "incomplete_safety_information",
                "product_allowed": False,
                "message": message,
            }
            session.screening = screening
            session.diagnosis_complete = True
            incomplete_safety = {
                "safe_to_recommend": False,
                "requires_doctor": True,
                "red_flag": False,
                "reason_code": "unanswered_safety_question",
                "reasons": sorted(safety_unknowns),
                "message": message,
            }
            return {
                "status": "SAFETY_REVIEW",
                "message": message,
                "recommendations": [],
                "safety": incomplete_safety,
                "screening": screening,
            }

        # A required question is never bypassed by the max-question fallback.
        # If we still have active question context, keep the assessment blocked.
        if session.last_question:
            logger.warning(
                "[SAFETY][BLOCK] reason=required_question_unanswered field=%s",
                session.last_question,
            )
            return {
                "status": "ASK",
                "message": _with_diarrhea_guidance(
                    "I still need an answer to the question above before I can complete the assessment.",
                    session.symptom_state,
                    session=session,
                ),
                "recommendations": [],
                "safety": safety,
            }

        # Hard stop: never loop forever. Produce the best available assessment.
        screening = evaluate_screening(session.symptom_state)
        screening = self._add_bristol_evidence(screening, session.symptom_state)
        if screening.get("pattern") == "Insufficiently characterized gut symptom pattern":
            screening = dict(screening)
            screening["pattern"] = "Preliminary gut-symptom assessment"
            screening["likely_condition"] = "Preliminary gut-symptom assessment"
            screening["message"] = "The available answers point to a gut-symptom pattern, but they do not support a more specific preliminary assessment yet."
        if screening.get("action") != "urgent_medical_evaluation" and not session.summary_reviewed:
            session.screening = screening
            return self._summary_review_result(session)
        if screening.get("product_allowed") and screening.get("pattern") in PRODUCT_ELIGIBILITY:
            allowed = _approved_names_for_screening(screening, session.symptom_state)
            result = evaluate_product(session.symptom_state, user_message, allowed_names=allowed, match_context=screening.get("pattern"))
            result = _filter_approved_products(result, screening, session.symptom_state)
            if result.get("status") in ("RECOMMENDATION_FOUND", "AMBIGUOUS"):
                result["screening"] = screening
                result["safety"] = safety
                return self._remember_recommendation(session, result)
        session.diagnosis_complete = True
        return {"status": "DIAGNOSIS", "message": _with_diarrhea_guidance(screening["message"], session.symptom_state, screening, session), "recommendations": [], "safety": safety, "screening": screening}


def re_fullmatch_number(text):
    return bool(re.fullmatch(r"\s*\d+(?:\.\d+)?\s*", text or ""))
