"""GutGPT language layer.

Clinical pattern selection is performed by clinical_rule_engine.py. Groq only
turns the structured result into a clear conversational answer.
"""
import os
import re
from langchain_core.prompts import PromptTemplate
from recommendation_engine import products as ALL_PRODUCTS
from llm_provider import create_client, invoke_provider

invoke_groq = invoke_provider

_ALL_PRODUCT_NAMES = [p.get("product_name", "") for p in ALL_PRODUCTS if p.get("product_name")]

RESPONSE_PROMPT_TEMPLATE = """
You are GutGPT, Guttify's gut-health assessment and product assistant.

Your job is to explain a STRUCTURED CLINICAL SCREENING RESULT that has already
been calculated by the deterministic rule engine. Do not change the result,
add a different condition, or invent missing facts.

The user wants useful diagnostic-style reasoning. Therefore, when a likely
condition/pattern is supplied, state it clearly as a PRELIMINARY / LIKELY
ASSESSMENT. Do not weaken every answer into a generic "I can't diagnose"
response. Do not present a chat assessment as a confirmed medical diagnosis.

Rules:
1. Use ONLY the supplied SCREENING RESULT for the clinical assessment.
2. Explain why the pattern was selected using the supplied evidence.
3. If differentials are supplied, mention the main alternatives briefly.
4. If confidence is low/insufficient, say that more information or medical
   assessment is needed instead of inventing certainty.
5. If the action is urgent_medical_evaluation, prioritize medical evaluation
   and do NOT recommend a product. If the action is medical_review and the
   rule engine supplied an approved product, present that product only as
   supportive wellness information after the medical-review guidance.
6. If product information is supplied, the products are allowed only because
   the rule engine explicitly allowed them. Present them after the assessment.
7. Never claim a product cures or treats a disease.
8. Never invent product facts, ingredients, dosage, warnings, price, links, or
   benefits. Use only CURRENT APPROVED PRODUCT(S).
9. Do not mention any Guttify product other than CURRENT APPROVED PRODUCT(S).
10. Do not diagnose a disease solely because a product exists for it.
11. Keep the answer clear and reasonably concise.
12. Do not append a generic wellness/medical disclaimer footer.

CONVERSATION HISTORY:
{conversation_history}

CURRENT USER MESSAGE:
{user_query}

SCREENING RESULT:
{screening_result}

CURRENT APPROVED PRODUCT(S):
{product_information}

FORMAT when a likely assessment exists:
Likely assessment: [condition/pattern]

Why:
- [evidence]

What this means:
[plain-English interpretation]

What to do next:
[action]

Possible alternatives:
[only if supplied and useful]

If products are approved:
Guttify product(s) that match this assessment:
[list each approved product name]

[brief relevant support for each product, using only supplied product information]
[usage/warnings/link only from supplied product information]
"""

response_prompt = PromptTemplate(
    template=RESPONSE_PROMPT_TEMPLATE,
    input_variables=["conversation_history", "user_query", "screening_result", "product_information"],
)


def load_llm():
    client = create_client(500, output_mode="text")
    if client is None:
        raise RuntimeError("The configured GutGPT language model provider is not available.")
    return client


def _bullets(items):
    return "\n".join(f"- {item}" for item in items)


def format_product_information(product):
    """Format one approved product or a list of approved products.

    A tied recommendation (AMBIGUOUS) can contain multiple products. Keep all
    of them in the same assessment response so the diagnosis is not lost and
    the LLM cannot invent products outside the deterministic allow-list.
    """
    if not product:
        return "NO APPROVED PRODUCT."
    products = product if isinstance(product, list) else [product]
    blocks = []
    for item in products:
        flavor_line = ""
        if item.get("flavors"):
            flavor_line = f"\nFlavors: {', '.join(item['flavors'])}"
        elif item.get("variants"):
            flavor_line = "\nVariants:\n" + "\n".join(
                f"- {v['flavor']}: {v['url']}" for v in item["variants"]
            )
        blocks.append(
            f"Product name: {item.get('product_name','')}\n"
            f"Category: {item.get('category','')}\n"
            f"Intended support:\n{_bullets(item.get('intended_support', []))}\n"
            f"Ingredients:\n{_bullets(item.get('ingredients', []))}\n"
            f"How to use: {item.get('how_to_use','')}\n"
            f"Warnings:\n{_bullets(item.get('warnings', []))}\n"
            f"Product link: {item.get('product_url','')}"
            f"{flavor_line}"
        )
    return "\n\n--- APPROVED PRODUCT ---\n\n".join(blocks)


def format_conversation_history(history):
    if not history:
        return "No previous conversation."
    return "\n".join(
        f"{'User' if m['role']=='user' else 'GutGPT'}: {m['content']}" for m in history
    )


def _mentions_unapproved_product(reply_text, approved_product):
    approved_products = approved_product if isinstance(approved_product, list) else [approved_product]
    approved_names = {
        p.get("product_name", "").lower()
        for p in approved_products
        if p and p.get("product_name")
    }
    low = reply_text.lower()
    # When no product was approved, no product name is allowed in the LLM
    # response. This keeps the database as the single source of product truth.
    return any(name.lower() in low for name in _ALL_PRODUCT_NAMES if name and name.lower() not in approved_names)


def _all_approved_links_mentioned(reply_text, approved_product):
    """Check if all approved products' URLs are mentioned in the reply."""
    approved_products = approved_product if isinstance(approved_product, list) else [approved_product]
    if not approved_products:
        return True
    low = reply_text.lower()
    for p in approved_products:
        url = p.get("product_url", "")
        if url and url.lower() not in low:
            return False
    return True


def _deterministic_screening_reply(screening, product=None):
    if not screening:
        return "I need a little more information before I can assess the pattern."
    parts = [f"Likely assessment: {screening.get('likely_condition', screening.get('pattern', 'Insufficient information'))}"]
    evidence = screening.get("evidence") or []
    if evidence:
        parts += ["", "Why:"] + [f"- {x}" for x in evidence]
    parts += ["", "What to do next:", screening.get("message") or "Follow the next-step guidance from a healthcare professional if symptoms persist or worsen."]
    if screening.get("differentials"):
        parts += ["", "Possible alternatives:", ", ".join(screening["differentials"])]
    if product:
        products = product if isinstance(product, list) else [product]
        parts += ["", "Guttify product(s) that match this assessment:"]
        for item in products:
            parts += ["", item.get("product_name", "")]
            if item.get("intended_support"):
                parts += ["Relevant support:", "- " + "\n- ".join(item["intended_support"][:4])]
            if item.get("how_to_use"):
                parts += ["How to use:", item["how_to_use"]]
            if item.get("warnings"):
                parts += ["Important warnings:", "- " + "\n- ".join(item["warnings"])]
            if item.get("product_url"):
                parts += ["Product link:", item["product_url"]]
    return "\n".join(parts)



def _deterministic_product_reply(product, user_query=""):
    """Product-only fallback. Never includes clinical screening/history."""
    if not product:
        return "I don't have product information available for that request."

    q = (user_query or "").lower()
    name = product.get("product_name", "this product")

    if "ingredient" in q or "contents" in q or "contain" in q:
        parts = [f"Ingredients in {name}:"]
        parts += [f"- {x}" for x in product.get("ingredients", [])]
        if product.get("warnings"):
            parts += ["", "Important warning:", f"- {product['warnings'][0]}"]
        return "\n".join(parts)

    if any(term in q for term in ("instruction", "usage", "dosage", "dose", "how do i take", "how should i take", "when should i take")):
        parts = [f"How to use {name}:"]
        if product.get("how_to_use"):
            parts.append(product["how_to_use"])
        if product.get("warnings"):
            parts += ["", "Important warnings:", "- " + "\n- ".join(product["warnings"])]
        if product.get("product_url"):
            parts += ["", "Product link:", product["product_url"]]
        return "\n".join(parts)

    parts = [f"{name}"]
    if product.get("intended_support"):
        parts += ["", "What it supports:", "- " + "\n- ".join(product["intended_support"][:5])]
    if product.get("ingredients"):
        parts += ["", "Ingredients:", "- " + "\n- ".join(product["ingredients"])]
    if product.get("how_to_use"):
        parts += ["", "How to use:", product["how_to_use"]]
    if product.get("warnings"):
        parts += ["", "Important warnings:", "- " + "\n- ".join(product["warnings"])]
    if product.get("product_url"):
        parts += ["", "Product link:", product["product_url"]]
    return "\n".join(parts)

def generate_response(llm, user_query, conversation_history, product=None, screening=None, mode="ASSESSMENT"):
    # PRODUCT_INFO mode deliberately excludes conversation history and the
    # prior screening result. A product question after diagnosis must answer
    # the product question only; old clinical text is not relevant context.
    if mode == "PRODUCT_INFO":
        product_info = format_product_information(product)
        product_prompt = f"""
You are GutGPT, a Guttify product information assistant.

Answer ONLY the user's current product-information question using the supplied product data.
Do NOT mention, repeat, summarize, or infer any previous diagnosis, assessment, symptoms, or clinical reasoning.
Do NOT recommend a different Guttify product.
Do NOT invent ingredients, benefits, dosage, warnings, links, or other product facts.
If the user asks for ingredients, give the ingredients from the supplied data directly.
Keep the answer concise and focused on what the user asked.

CURRENT USER QUESTION:
{user_query}

APPROVED PRODUCT DATA:
{product_info}
"""
        try:
            candidate = invoke_groq(llm, product_prompt, reason="legacy_product_response").content
            if not _mentions_unapproved_product(candidate, product):
                return candidate
        except Exception:
            pass
        return _deterministic_product_reply(product, user_query)

    history_text = format_conversation_history(conversation_history)
    screening = screening or {}
    product_info = format_product_information(product)
    prompt_text = response_prompt.format(
        conversation_history=history_text,
        user_query=user_query,
        screening_result=screening,
        product_information=product_info,
    )

    for attempt in range(2):
        if attempt:
            prompt_text += "\n\nCorrection: stay strictly within the supplied screening result and approved product."
        try:
            candidate = invoke_groq(llm, prompt_text, reason="legacy_response").content
            if not product or (not _mentions_unapproved_product(candidate, product) and _all_approved_links_mentioned(candidate, product)):
                return candidate
        except Exception:
            break
    return _deterministic_screening_reply(screening, product)


def chatbot():
    print("\n" + "=" * 60)
    print("                         GUTGPT")
    print("=" * 60)
    print("\nHi! I'm GutGPT, Guttify's gut-health assessment assistant.")
    llm = load_llm()
    history = []
    while True:
        user_query = input("\nYou:\n> ").strip()
        if user_query.lower() in ("exit", "quit", "bye"):
            print("\nThank you for using GutGPT.")
            break
        if not user_query:
            continue
        print("\nGutGPT is assessing your symptoms...")
        # CLI single-turn mode remains available for product lookup projects;
        # the web app uses ConversationManager for the full multi-turn flow.
        from recommendation_engine import recommend_product
        result = recommend_product(user_query)
        if result.get("status") in ("RECOMMENDATION_FOUND", "PRODUCT_INFO_FOUND"):
            product = result["recommendations"][0]
            answer = generate_response(llm, user_query, history, product, result.get("screening"))
        else:
            answer = result.get("message") or "Please provide more detail about your symptoms."
        print("\n" + answer)
        history.extend([{"role":"user","content":user_query},{"role":"assistant","content":answer}])
